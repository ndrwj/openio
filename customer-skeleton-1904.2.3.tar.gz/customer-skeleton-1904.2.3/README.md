Customer Skeleton
===

Description
---

This repository should serve as a template for all customer deployments. Its functions are:

- To provide access information for sysadmins
- To provide an understandable overview of the customer platform
- To version the deployment resources

This document needs to be filled up and put online after the deployment is completed. If some information is missing, it must be tagged as **TODO**. Once all the pieces have been added, a release needs to be made (see below).

User guide
---

#### Init the new customer

```
git clone git@github.com:open-io/customer-skeleton.git customer-<NAME>
git remote set-url origin git@github.com:open-io/customer-<NAME>.git
git push origin master
```

#### Update the new description in the README.sample.md as follows:

- Description: a short description of the platform. Should give an rough idea on its size, number of sites, servers, and the use case. *Example: This is a production cluster of 10 nodes on 2 sites used for S3 backup, with a 2PB capacity.*

- Access: specify the access type (Direct, Gateway, VPN, External software), then provide a short yet efficient way to access the platform. Providing an ssh config file is useful, as well as instructions to use external software or VPN.

** Example:**
> Access type: Gateway
```sh
ssh -i ./ssh/id_rsa.pub openio@gateway.example.com
Password: changeme
```

- Topology: Add a row for each node specifying the hostname and its function (Storage/Front/Gateway/Admin/OIOFS...)

- Infrastructure: Draw an infrastructure diagram, commit it to the repo and add the link in this section.

- Software: For each component, specify its version or N/A. You can describe more components if necessary.

- Deployment report: Add a link to the deployment report

- Tools: Fill the table with the credentials to access and use the tools installed on the platform.

- Contacts: add the slack channel for the customer, and describe primary contacts on the customer side.

Once filled up:

```
mv README.sample.md README.md
git commit -a
git push origin master
```

Resources, Tools
---

If additional resources are available, add them to a **resources** folder. If custom tools are in use, add them to a **tools** folder.

Ansible
---

When applicable, commit the **ansible-playbook-openio-deployment** folder used to deploy the cluster.

Release
---

Once all components are filled, you can create a new 1.0.0 release of the customer repo. You can add additional releases afterwards, although not every change should result in a new release for efficiency purposes. The master should remain the primary reference used by sysadmins (i.e. it should be **working** and **up to date**).

#!/bin/bash
#
# ./changelog.sh
#
# Description:
#
# Prints a changelog for the parent repo and dependencies. Diff is created from a [target] starting from a [reference]
#
# Target and reference must be BOTH either tags/branches or commits (both can't be mixed)
#
# Requirements:
#
# git, sqlite3, GitHub private repo access (RSA key or GITHUB_TOKEN)
#
# Examples:
#
# ./changelog.sh -t origin/18.10 -r 1810.0.1
# > Diffs the HEAD of branch 18.10 with the tag 1810.0.1
#
# ./changelog.sh -t 02326f90 -r f55cd096
# > Diffs 2 commits

function usage {
    echo -e "Usage $0 -r REFERENCE -t TARGET\n"
    echo " -r REFERENCE       oldest commit/tag to diff"
    echo " -t TARGET          newest commit/tag/branch to diff"
    echo " -w WORKDIR         path to cache directory (default ./tmp)"
    echo " -h                 display help"
    echo -e "\nExamples:"
    echo -e "
    $0 -r 1810.0.1 -t origin/18.10
        > Diffs the HEAD of branch 18.10 with the tag 1810.0.1

    $0 -r 1810.0.1 -t 1810.0.2
        > Diffs the tag 1810.0.2 with the tag 1810.0.1

    $0 -t 02326f90 -r f55cd096
        > Diffs 2 commits\n"
}

function main {
    WORKDIR="./tmp/"
    BASE_URL="git@github.com:open-io/customer-skeleton.git"
    REQ_PATH="deployment/sds/requirements.yml"
    ref=""
    branch=""

    if ! which git &> /dev/null || ! which sqlite3 &> /dev/null; then
        echo "This program requires git and sqlite3"
        exit 1
    fi

    while getopts ":r:t:w:h" opt; do
      case $opt in
        h)
            usage
            exit 0
            ;;
        r)
            ref=${OPTARG}
            ;;
        t)
            branch=${OPTARG}
            ;;
        w)
            WORKDIR=${OPTARG}
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            usage
            exit 1
            ;;
        :)
            echo "Option -$OPTARG requires an argument." >&2
            usage
            exit 1
            ;;
      esac
    done

    if [ "$ref" == "" ] || [ "$branch" == "" ]; then
        usage
        exit 1
    fi

    # If one of the refs is a commit, use commit-to-commit compare mode
    HEX_REGEXP=^[a-fA-F0-9]+$

    if [[ "$ref" =~ $HEX_REGEXP ]] || [[ "$branch" =~ $HEX_REGEXP ]]; then
        if [[ ! "$ref" =~ $HEX_REGEXP ]] || [[ ! "$branch" =~ $HEX_REGEXP ]]; then
            echo "ERROR: commits can only be compared to other commits"
            exit 1
        fi
    fi

    db=$(mktemp)
    sqlite3 "$db" "create table repos(name String, url String, old String, new String)"

    if [ -d "${WORKDIR}" ]; then
        cd ${WORKDIR}
        git fetch &> /dev/null
    else
        git clone ${BASE_URL} ${WORKDIR} &> /dev/null
        cd ${WORKDIR}
    fi

    # Log parent repo diff

    echo -e "### $(basename -s .git ${BASE_URL})\n"
    diffs=$(git log "${ref}..${branch}" --pretty="format:- %s" | cat | grep -v "^- BUMP")

    no_check=false
    if [[ "$diffs" == "" ]]; then
        no_check=true
        diffs="-- No changes --"
    fi
    echo -e "$diffs"
    echo -e "\n---\n"

    if "$no_check"; then
        (>&2 echo "Parent repo is unchanged; Skipping dependency checks")
        exit 0
    fi

    # Fetch refs of dependencies

    git checkout ${ref} &> /dev/null
    grep -E "src|version" ${REQ_PATH} | awk -F ": " '{print $2}' |
        while read repo; read version; do
            reponame=$(basename -s .git ${repo})
            sqlite3 "$db" "INSERT INTO repos (name,url,old,new) VALUES ('$reponame','$repo','$version','');"
        done

    git checkout ${branch} &> /dev/null
    grep -E "src|version" ${REQ_PATH} | awk -F ": " '{print $2}' |
        while read repo; read version; do
            reponame=$(basename -s .git ${repo})
            # TODO: handle new roles
            sqlite3 "$db" "UPDATE repos SET new='$version' where url='$repo';"
        done

    # Log dependency diff

    mkdir -p "deps/"
    sqlite3 -separator ' ' "$db" "select name,url,old,new from repos" | tr ' ' '\n' |
        while read name; read url; read old; read new; do
            if [[ "$new" != "$old" ]]; then
                echo -e "#### $name\n"
                if [ -d "deps/$name" ]; then
                    pushd "deps/$name" &> /dev/null
                    git fetch &> /dev/null
                else
                    git clone -q "$url" "deps/$name" &> /dev/null
                    pushd "deps/$name" &> /dev/null
                fi
                diffs=$(git log "${old}..${new}" --pretty="format:- %s" | cat)

                if [[ "$diffs" == "" ]]; then
                    diffs="-- No changes --"
                fi
                echo -e "$diffs"
                popd &> /dev/null
                echo -e "\n---\n"
            fi
        done
}

main "$@"

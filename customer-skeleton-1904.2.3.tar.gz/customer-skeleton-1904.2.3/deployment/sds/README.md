# Table of Contents
1. [SDS](#SDS)
2. [OIOFS](#OIOFS)

<a name="SDS"></a>
# SDS

## Github repository

In our organization, you have to create a repository `customer-NAME`

## SSH key
Generate de ssh key and give the public part to the customer
<details><summary>details</summary>
<p>

```shell
cd ssh
openssl rand -base64 10 > id_rsa.passwd
cat id_rsa.passwd
ssh-keygen -f ./id_rsa
```
</p>
</details>

## Requirements
This deployment uses `ansible`. You can install it with your package manager or create a python-virtual
<details><summary>details</summary>
<p>

```shell
virtualenv venv
. ./venv/bin/activate
pip install -r ansible.pip
```
</p>
</details>

### Disks are not mounted and defined in fstab
If your customer doesn't prepare the server, you can prepare the server like this:
#### Partition creation
Here `sdac` is the system device and all others devices are dedicated to openio
```shell
for i in $(ls -1  /dev/sd* | grep -v "sdac"); do parted -a optimal ${i}  -s mklabel gpt unit TB mkpart primary 0% 100% ; done
```
#### Format partition
Here `sdac` is the system device and all others devices are dedicated to openio
```shell
num=1 && for i in $(ls -1  /dev/sd*1 | grep -v "sdac" | awk -F\: '{print $1}'); do echo "mkfs.xfs -f -L SATA-${num} $i "; num=$((num + 1)); done
```
#### fstab generation
Here `sdac` is the system device and all others devices are dedicated to openio

```shell
boucle=0
for i in $(blkid  | grep "SATA" | awk -F\: '{print $2}' | awk '{print $2}' | sed 's/UUID="\(.*\)"/\1/')
do
boucle=$(($boucle+1))
echo "UUID=${i} /mnt/disk${boucle} xfs defaults,noatime,noexec 0 0"
done
```
#### Ansible host_vars
`mnt` is the common path to the mountpoints
```shell
df |grep mnt | awk '{print "        - mountpoint: "$NF"\n          partition: "$1}'
```

### How to use ARA
It makes your Ansible playbooks easier to understand and troubleshoot.
<details><summary>details</summary>
<p>

```shell
export ANSIBLE_CALLBACK_PLUGINS=$(python -m ara.setup.callback_plugins)

ansible-playbook myplaybook.yml

ara-manage runserver
# Browse http://127.0.0.1:9191
```
</p>
</details>

## Adjust major settings in the inventory
In the file `inventory.yml`, you can choose main settings:

### Namespace
<details><summary>details</summary>
<p>

```yaml
openio:
  children:
    fronts: {}
    backs: {}
    admin: {}
    oiogrid: {}

  vars:
    namespace: OPENIO
    namespace_storage_policy: "ECISAL63D1"

    openio_bind_interface: '{{ ansible_default_ipv4.alias }}'
    openio_bind_address: '{{ ansible_default_ipv4.address }}'
    openio_bind_virtual_address: "10.0.2.137"
    openio_bind_virtual_address_mask: "8"
    openio_vrrp_id: "42"

    openio_database_keystone_password: KEYSTONE_PASS
    openio_database_root_password: ROOT_PASS
    openio_database_sst_password: SST_PASS
    openio_grafana_password: admin
    openio_grafana_secret_key: 59b579be5dfcfd1d4cc56a8c52d8d700
    openio_grafana_user: admin
    openio_haproxy_password: HA_PASS
    openio_keepalived_password: KEEP_PASS
    openio_keystone_admin_password: ADMIN_PASS
    openio_keystone_demo_password: DEMO_PASS
    openio_keystone_swift_password: SWIFT_PASS

```
</p>
</details>

### Network: interface
In the case that there is a specific, non-default interface to be used for OpenIO, you need to define it here:
```yaml
openio_bind_interface: eth1
openio_bind_address: "{{ ansible_eth1.ipv4.address }}"
```
You can also directly define the IP to be used for each node via `openio_bind_address` in the inventory file.
<details><summary>details</summary>
<p>

```yaml
node1:
  ansible_host: 10.0.2.134  # ssh deployment
  openio_bind_address: "{{ ansible_eth1.ipv4.address }}" # data address
  openio_data_mounts: []
  openio_metadata_mounts: []
```
</p>
</details>

### Network: VIP
A virtual IP address is needed for the HA (used by haproxy and keepalived)

:exclamation: Nodes must share the same LAN for keepalived.
```yaml
openio:
  vars:
    openio_bind_virtual_address: "10.0.2.137"
    openio_bind_virtual_address_mask: "8"
    openio_vrrp_id: "42"
```

### Systemd: enable services at boot
In the scope of SDS or Monitoring, these services are enabled at server boot. (default: true)

```yaml
all:
  vars:
    openio_services_systemd_enabled: false
```

### Security: passwords
Today, all password are in clear in this file :-(

All deployments should ideally have unique passwords set from the start, as it will be impossible to change most of them without downtime once the platform is in production.
<details><summary>details</summary>
<p>

```yaml
all:
  children:
    openio:
      vars:
        openio_database_keystone_password: KEYSTONE_PASS
        openio_database_root_password: ROOT_PASS
        openio_database_sst_password: SST_PASS
        openio_grafana_password: admin
        openio_grafana_secret_key: 59b579be5dfcfd1d4cc56a8c52d8d700
        openio_grafana_user: admin
        openio_haproxy_password: HA_PASS
        openio_keepalived_password: KEEP_PASS
        openio_keystone_admin_password: ADMIN_PASS
        openio_keystone_demo_password: DEMO_PASS
        openio_keystone_swift_password: SWIFT_PASS
```
</p>
</details>

For `openio_grafana_secret_key` you can use:
```console
# cat /proc/sys/kernel/random/uuid | md5sum | cut -d' ' -f1
c72430e75d53f9d9007b9ab4c42140cc
```

When installed closed-source components, you need to specify the user/password of the corresponding private mirror.
<details><summary>details</summary>
<p>

```yaml
all:
  children:
    openio:
      vars:
        openio_repositories_credentials:
          g4a:
            user: foo
            password: bar
          replicator:
            user: foo
            password: bar
```
</p>
</details>

You can encrypt your password with `ansible-vault` and with a master password (`foo` here)
<details><summary>details</summary>
<p>

```console
# ansible-vault encrypt_string MY_PASSWORD --ask-vault-pass
New Vault password: foo
Confirm New Vault password: foo
!vault |
  $ANSIBLE_VAULT;1.1;AES256
  65663238353061323936333162343436303535323561613363393136323331666333616231346233
  3434643961636534316435613162656436363663316165310a326565623131656565356565383235
  39326662643336343236356134623261316136353831636165663261353261316334623635633935
  3134323761653839320a396134643065393435363339666462333963303666393261363330376430
  6232
```
</p>
</details>

An example for `openio_database_keystone_password`:
<details><summary>details</summary>
<p>

```yaml
all:
  children:
    openio:
      vars:
        openio_database_keystone_password: !vault |
          $ANSIBLE_VAULT;1.1;AES256
          65663238353061323936333162343436303535323561613363393136323331666333616231346233
          3434643961636534316435613162656436363663316165310a326565623131656565356565383235
          39326662643336343236356134623261316136353831636165663261353261316334623635633935
          3134323761653839320a396134643065393435363339666462333963303666393261363330376430
          6232
```
</p>
</details>

With encrypted password, you have to add `--ask-vault-pass` to your command `ansible-playbook -i inventory.yml main.yml -e "openio_bootstrap=true" -e "openio_maintenance_mode=false" --ask-vault-pass`

```console
# ansible-playbook -i inventory.yml main.yml -e "openio_bootstrap=true" -e "openio_maintenance_mode=false" --ask-vault-pass
Vault password: foo
```

## host_vars: Node settings
SDS use disks referenced here
<details><summary>details</summary>
<p>

```yaml
all:
  hosts:
    # node without SDS
    node1:
      ansible_host: 10.0.2.130
      openio_data_mounts: []
      openio_metadata_mounts: []
    # node with data or meta data
    node2:
      ansible_host: 10.0.2.135
      openio_data_mounts:
        - mountpoint: /mnt/data1
          partition: /dev/vdb
        - mountpoint: /mnt/data2
          partition: /dev/vdc
        - mountpoint: /mnt/data3
          partition: /dev/vdd

      openio_metadata_mounts:
        - meta2_count: 8
          mountpoint: /mnt/metadata1
          partition: /dev/vde
        - meta2_count: 8
          meta1_count: 0
          mountpoint: /mnt/metadata2
          partition: /dev/vdf
...
```

</p>
</details>

`openio_data_mounts` is used for rawx, rdir, ...

`openio_metadata_mounts` is used for meta, zookeepers and redis

You can have multiple devices reserved for metadata; make sure you adjust `meta1_count` and `meta2_count` accordingly for each device.

## Inventory: Define service placement
After write the main declaration (address, user)
<details><summary>details</summary>
<p>

```yml
all:
  hosts:
    node1:
      ansible_host: 10.0.2.130
      openio_data_mounts: []
      openio_metadata_mounts: []
    node2:
      ansible_host: 10.0.2.134
      openio_data_mounts: []
      openio_metadata_mounts: []
    node3:
      ansible_host: 10.0.2.131
      openio_data_mounts: []
      openio_metadata_mounts: []
    node4:
      ansible_host: 10.0.2.132
      openio_data_mounts: []
      openio_metadata_mounts: []
    node5:
      ansible_host: 10.0.2.135
      openio_data_mounts: []
      openio_metadata_mounts: []
    node6:
      ansible_host: 10.0.2.133
      openio_data_mounts: []
      openio_metadata_mounts: []

    node7:
      ansible_host: 10.0.2.136
      openio_data_mounts: []
      openio_metadata_mounts: []

  vars:
    ansible_user: devops
```
</p>
</details>

Allocate your servers in each servicetype's groups
<details><summary>details</summary>
<p>

```yml
children:
  openio:
    children:
      fronts: {}
      backs: {}
      admin: {}
      oiogrid: {}
```
</p>
</details>

All servers must be a child of `openio`
<details><summary>details</summary>
<p>

```yml
# what is not used for storage
fronts:
  hosts:
    node2: {}
    node3: {}
    node4: {}
# what is used for storage
backs:
  hosts:
    node5: {}
    node6: {}
    node7: {}
```
</p>
</details>

Fronts/Backs is a conceptual split

```yml
### Monitoring
    admin:
      hosts:
        node1: {}
```
The admin node is used for monitoring and webui
<details><summary>details</summary>
<p>

```yml
meta:
  children:
    meta0: {}
    meta1: {}
    meta2: {}

meta0:
  hosts:
    node5: {}
    node6: {}
    node7: {}

meta1:
  hosts:
    node5: {}
    node6: {}
    node7: {}

meta2:
  hosts:
    node5: {}
    node6: {}
    node7: {}
```
</p>
</details>

Meta services can split like that

### Multi sites
For multi-datacenter deployments:
-  create groups for each entity, then add the nodes that are part of it.
<details><summary>details</summary>
<p>

```yml
all:
  children:
    site1:
      hosts:
        node5: {}
      vars:
        openio_location_rack: "site1."
    site2:
      hosts:
        node6: {}
      vars:
        openio_location_rack: "site2."
    site3:
      hosts:
        node7: {}
      vars:
        openio_location_rack: "site3."
```
</p>
</details>

#### With pools and slots
Now your have a location like: `site.host.id`, roles are configured to provide slots as (example for rawx):
```yaml
slots:
  - rawx
  - rawx-site1
```
Note: If you have a location like `region.site.host.id`, slots will be
```yaml
slots:
  - rawx
  - rawx-region-site1
```

- Declare nodes that will have meta1. For multisite deployments, make sure that there is 1 node per site declared. In the example below node1, node3 and node5 are all on different sites.
```yml
meta1:
  hosts:
    node1: {}
    node3: {}
    node5: {}
```

- Set the data protection (here for a ECISALC75D1 )
```yaml
  openio:

    vars:
      namespace: OPENIO
      namespace_storage_policy: "ECISALC75D1"
      openio_conscience_data_security_custom:
        ECISALC75D1: "ec/k=7,m=5,algo=isa_l_rs_cauchy"
        DUPONETHREE: "plain/distance=1,nb_copy=3"
```

- Declare your own storage policies
```yaml
  openio:

    vars:
      namespace: OPENIO
      namespace_storage_policy: "ECISALC75D1"
      openio_conscience_storage_policies_custom:
        ECISALC75D1: "rawx12:ECISALC75D1"
        THREECOPIES: "rawx3:DUPONETHREE"
```

- Configure your pools to match service's slots
<details><summary>details</summary>
<p>

```yaml
  openio:

    vars:
      namespace: OPENIO
      namespace_storage_policy: "ECISALC75D1"
      openio_conscience_pools:
        - name: rawx3
          targets:
            - slot: rawx-site1
              fallback: rawx
              count: 1
            - slot: rawx-site2
              fallback: rawx
              count: 1
            - slot: rawx-site3
              fallback: rawx
              count: 1
          min_dist: 2
          warn_dist: 2
        - name: rawx12
          targets:
            - slot: rawx-site1
              fallback: rawx
              count: 4
            - slot: rawx-site2
              fallback: rawx
              count: 4
            - slot: rawx-site3
              fallback: rawx
              count: 4
          min_dist: 1
          warn_dist: 1
          max_dist: 2
```
</p>
</details>

- Finally, disable the loadbalancer optimisation

```yaml
  openio:

    vars:
      namespace: OPENIO
      namespace_storage_policy: "ECISALC75D1"
      openio_namespace_options:
        - "core.lb.allow_distance_bypass=false"
```

#### Without pools and slots
- Declare your own storage policies
```yaml
  openio:

    vars:
      namespace: OPENIO
      namespace_storage_policy: "ECISALC75D1"
      ECISALC75D1: "ec/k=7,m=5,algo=isa_l_rs_cauchy,min_dist=1,warn_dist=1,max_dist=2"
      DUPONETHREE: "plain/distance=1,nb_copy=3,warn_dist=2,min_dist=2"
```


#### Test the distribution
<details><summary>details</summary>
<p>

```console
# openio object create MY_OBJECT /etc/magic --policy ECISALC75D1 --oio-account MY_ACCOUNT
+-------+------+----------------------------------+--------+
| Name  | Size | Hash                             | Status |
+-------+------+----------------------------------+--------+
| magic |  111 | 272913026300E7AE9B5E2D51F138E674 | Ok     |
+-------+------+----------------------------------+--------+

# openio object locate MY_OBJECT magic --oio-account MY_ACCOUNT  -c Id -f value |sort
http://172.31.130.30:6202/8FBA80C8227A61961C14A2A64161B9BC0987029A358984BDDA82CF20916F2CBE
http://172.31.130.31:6211/54FE5D18D1044A937B9E14569CE7FC70A14F70FEEEB65BFE45A7404BC1EB4F68
http://172.31.130.32:6202/2C609CDF9902B17A0E35B9A102E2E00B99033F2E411431DADD79C5DD23A89DB4
http://172.31.130.34:6207/D2461DFBA22A7872C82D56ECBD7227706D24072814A9C799780FBD8B34EFC19F
http://172.31.130.35:6202/985E6CD02DA2101604D053F31F066765576A859623F68AA6E5ACE4E0F37341D2
http://172.31.130.36:6209/0A0A8048634318F24B916424A3BD3DDD1F071B4E6D7BE74ACD84934D161A5EC3
http://172.31.130.37:6209/02C81ECA57660453D4F089E9A3EF9D13F65BBEDE78619212BFBBBAAC6E286509
http://172.31.130.38:6201/4ADAD5D92AFCB550EF9A487E1DE04EBEEE23F0F8E22E0A27C935FC609BD845C5
http://172.31.130.40:6203/B3B642D3A82E54B3173C31D2EB3851836C5C28AD038B4A909C03A483E7859FB9
http://172.31.130.41:6202/9B834D2CD3943289198857A4E9085AF215A76E63D7C6D042319E10F9A247DB5D
http://172.31.130.42:6202/C53B27788C70A5422B2794A07C295513F3A59697F7E04FDC22FD84B395B67E52
http://172.31.130.43:6201/D43D436520C8D44C2D4E2D3E98B2FB811FB3A1077EFE32FD3642132AA5FA0859
```
</p>
</details>

## Change the storage policies
https://docs.openio.io/latest/source/arch-design/storage_policies.html

Define all policies in the group `oioswift`
```yaml
oioswift:
  children:
    backs: {}
  vars:
    openio_oioswift_sds_oio_storage_policies:
      - THREECOPIES
      - FIVECOPIES
      - ECISALC75D1
```
The following configuration shows the configuration of DDP used by S3 (dynamic data protection):
- 3 replicas for small files (<256kiB),
- EC7+5 for large files (>=256kiB)
<details><summary>details</summary>
<p>

```yaml
oioswift:
  children:
    backs: {}
  vars:
    openio_oioswift_sds_auto_storage_policies:
      - ECISALC75D1        # used for files of unknown size
      - THREECOPIES:0      # 3 copies
      - ECISALC75D1:262144
```
</p>
</details>

## Configure the container hierarchy

You need to change the pipeline to use in the group `oioswift`

<details><summary>details</summary>
<p>

```yaml
oioswift:
  children:
    backs: {}
  vars:
    openio_oioswift_pipeline: "{{ pipeline_keystone_containerhierarchy }}"
```
</p>
</details>

## Configure the bucketDB

You need to change the swift3 middleware in the group `oioswift`

<details><summary>details</summary>
<p>

```yaml
oioswift:
  children:
    backs: {}
  vars:
    openio_oioswift_filter_swift3:
      use: "egg:swift3#swift3"
      force_swift_request_proxy_log: true
      s3_acl: true
      location: "{{ openio_s3_region }}"
      check_bucket_owner: true
      # always set same value
      max_bucket_listing: 1000
      max_multi_delete_objects: 1000
      storage_domain: "example.com"
      bucket_db_enabled: true
      bucket_db_sentinel_hosts:
        "{{ groups['redis'] \
        | map('extract', hostvars, ['openio_bind_address'])\
        | join(':6012,') }}:6012"
      bucket_db_master_name: OPENIO-master-1
      bucket_db_prefix: 's3bucket:'

```
</p>
</details>

## Increase the number of parts for multipart uploads

You need to change the `swift3` and the `slo` middlewares in the group `oioswift`

<details><summary>details</summary>
<p>

```yaml
oioswift:
  children:
    backs: {}
  vars:
    openio_oioswift_filter_swift3:
      use: "egg:swift3#swift3"
      force_swift_request_proxy_log: true
      s3_acl: true
      check_bucket_owner: true
      location: "{{ openio_s3_region | d('us-east-1') }}"
      max_bucket_listing: 1000        # must be equal to max_multi_delete_objects
      max_multi_delete_objects: 1000  # must be equal to max_bucket_listing
      max_upload_part_num: 10000      # increased to 10000
    openio_oioswift_filter_slo:
      use: "egg:swift#slo"
      max_manifest_segments: 10000    # increased to 10000
```
</p>
</details>

## Manage a second swift gateway

You need to split the group `oioswift` in 2 children.


<details><summary>details</summary>
<p>

```yaml
backs:
  hosts:
    server1: {}
    server2: {}
    server3: {}
    # these new nodes need to be children of the group openio
    server1bis: {}  # new
    server2bis: {}  # new
    server3bis: {}  # new
…
oioswift:
  children:
    #backs: {}
    oioswift1: {}
    oioswift2: {}  

oioswift1:
  hosts:
    server1: {}
    server2: {}
    server3: {}
  vars: {}

oioswift2:
  hosts:
    server1bis:
      ansible_host: 10.0.2.219  # same as server1
    server2bis:
      ansible_host: 10.0.2.220  # same as server2
    server3bis:
      ansible_host: 10.0.2.217  # same as server3
  vars:
    openio_oioswift_sds_default_account: images
    openio_oioswift_serviceid: 1
    openio_oioswift_bind_port: 6666
```
</p>
</details>

## Change user openio's UID/GID:
They are defined in the group `all`

```yaml
all:
  vars:
    # openio's GID
    openio_group_openio_gid: 220
    # openio's UID
    openio_user_openio_uid: 120
```

## Define a low usage (ARM, Docker, …)
Add to the group `all` these paramaters:

```yaml
all:  
  vars:

    # low profile
    openio_account_workers: 1
    openio_oioswift_workers: 1
    namespace_meta1_digits: "1"
    openio_event_agent_workers: 1
    openio_zookeeper_parallel_gc_threads: 1
    openio_zookeeper_memory: "256M"
    openio_minimal_score_for_volume_admin_bootstrap: 5
    openio_minimal_score_for_directory_bootstrap: 5
    openio_keystone_wsgi_processes: 1
    openio_keystone_wsgi_threads: 1
```

## Working behind a proxy server
Working behind a proxy require to fill the `openio_environment` with all data addresses
```yaml
all:
  vars:
    openio_environment:
      http_proxy: "http://myproxy:3128"
      https_proxy: "http://myproxy:3128"

      # https://www.gnu.org/software/wget/manual/html_node/Proxies.html
      no_proxy: "localhost,\
        vip1,vip2,vip…,\
        openio_bind_address1,openio_bind_address2,openio_bind_address3…"
```

example:
```yaml
all:

  vars:
    openio_environment:
      http_proxy: "http://192.168.10.50:3128"
      https_proxy: "http://192.168.10.50:3128"

      # https://www.gnu.org/software/wget/manual/html_node/Proxies.html
      no_proxy: "localhost,\
        172.25.10.101,172.25.10.102,172.25.10.103,\
        172.25.10.51,172.25.10.52,172.25.10.53,172.25.10.54,172.25.10.55,172.25.10.56,172.25.10.57,172.25.10.58"
```

## Oioswift: Use TempAuth instead of Keystone
The enterprise version is by design configured to use keystone as API client authentication

In some cases, you can need to use the `tempauth` authentication.

In the group `openio`, add this part:
<details><summary>details</summary>
<p>

```yaml
  openio:

    vars:
      namespace: OPENIO
      # S3 users (tempauth)
      openio_oioswift_users:
        - name: "demo:demo"
          password: "DEMO_PASS"
          roles:
            - admin
      openio_oioswift_pipeline: "{{ pipeline_tempauth }}"
      openio_oioswift_filter_tempauth:
        "{{ {'use': 'egg:oioswift#tempauth'} | combine(openio_oioswift_users | dict_to_tempauth) }}"
```
</p>
</details>

Finally, empty the keystone'group in the inventory yml-file
```yaml
keystone:
  children: {}
```

## Add a certificate to oioswift

The SSL is provided by HAPROXY.
<details><summary>details</summary>
<p>

```yaml
haproxy:
  hosts:
    node2: {}
    node3: {}
  vars:
    haproxy_swift_public_frontend_bind: "{{ openio_bind_virtual_address }}:443 ssl crt /etc/letsencrypt/live/swift.openio.io/fullchain.pem"
    #haproxy_global_ca_base: /etc/ssl
    #haproxy_global_crt_base: /etc/ssl
```
</p>
</details>

To create a `.pem` with the private key and entire trust chain
```console
-----BEGIN RSA PRIVATE KEY-----
(Your Private Key: mydomain.org.key)
-----END RSA PRIVATE KEY-----
-----BEGIN CERTIFICATE-----
(Your Primary SSL certificate: mydomain.org.crt)
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
(Your Intermediate certificate: intermediateCA.crt)
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
(Your Root certificate: TrustedRoot.crt)
-----END CERTIFICATE-----
-----BEGIN X9.42 DH PARAMETERS-----
(Your DH paramaters)
-----END X9.42 DH PARAMETERS-----
```

Generate DH params with a given length `openssl dhparam -out dhparams.pem [bits]`

## Add a second virtual IP

The most common case is to expose the swift on a public VIP. The rest of the services stay on the internal VIP
<details><summary>details</summary>
<p>

```yaml
# new meta group
ha:
  children:
    haproxy: {}
    keepalived: {}
  vars:
    openio_bind_virtual_address_external: 172.31.140.12
    openio_bind_virtual_address_external_mask: 24
    openio_bind_virtual_address_external_interface: eth2
    openio_bind_virtual_address_external_vrrip: "42"
    haproxy_swift_external_frontend_bind: 6007

haproxy:
  hosts:
    node2: {}
    node3: {}
  vars:
    haproxy_frontend_instances:
      # NEW
      # SWIFT EXTERNAL
      - name: "swift-external"
        mode: http
        bind: "{{ openio_bind_virtual_address_external }}:{{ haproxy_swift_external_frontend_bind }}"
        log-format: "{{ haproxy_log_format_https }}"
        unique-id-format: "{{ haproxy_defaults_unique_id_format }}"
        unique-id-header: "{{ haproxy_defaults_unique_id_header }}"
        ? "acl METH_PUT method PUT \n
          # Fix Eventlet 'Expect' header handling with uppercase '100-Continue' \n
          # https://github.com/eventlet/eventlet/pull/523 \n
          acl header_expect_exists req.hdr(Expect) -m found \n
          http-request replace-header Expect ^(.*)-Continue$ \\1-continue if METH_PUT header_expect_exists \n
          # Set 'Content-Length' header to 0 in PUT requests when not present \n
          acl header_content_length_exists    req.hdr(Content-Length) -m found \n
          acl header_transfer_encoding_exists req.hdr(Transfer-Encoding) -m found \n
          http-request set-header Content-Length 0 if METH_PUT
            !header_content_length_exists !header_transfer_encoding_exists \n
          reqadd X-Forwarded-Proto:\\"
        : "{{ haproxy_swift_public_frontend_proto }}"
        option:
          - "forwardfor"
        capture:
          - "request header Host len 60"
          - "request header X-Unique-ID len 46"
          - "request header X-Client-IP len 24"
        default_backend: "swift-backend"

      # copied from role's default
      # SWIFT INTERNE
      - name: "swift-public"
        mode: http
        bind: "{{ haproxy_swift_public_frontend_bind }}"
        log-format: "{{ haproxy_log_format_https }}"
        unique-id-format: "{{ haproxy_defaults_unique_id_format }}"
        unique-id-header: "{{ haproxy_defaults_unique_id_header }}"
        ? "acl METH_PUT method PUT \n
          # Fix Eventlet 'Expect' header handling with uppercase '100-Continue' \n
          # https://github.com/eventlet/eventlet/pull/523 \n
          acl header_expect_exists req.hdr(Expect) -m found \n
          http-request replace-header Expect ^(.*)-Continue$ \\1-continue if METH_PUT header_expect_exists \n
          # Set 'Content-Length' header to 0 in PUT requests when not present \n
          acl header_content_length_exists    req.hdr(Content-Length) -m found \n
          acl header_transfer_encoding_exists req.hdr(Transfer-Encoding) -m found \n
          http-request set-header Content-Length 0 if METH_PUT
            !header_content_length_exists !header_transfer_encoding_exists \n
          reqadd X-Forwarded-Proto:\\"
        : "{{ haproxy_swift_public_frontend_proto }}"
        option:
          - "forwardfor"
        capture:
          - "request header Host len 60"
          - "request header X-Unique-ID len 46"
          - "request header X-Client-IP len 24"
        default_backend: "swift-backend"

      # copied from role's default
      # KEYSTONE ADMIN
      - name: "keystone-admin"
        mode: http
        bind: "{{ haproxy_keystone_admin_frontend_bind }}"
        log-format: "{{ haproxy_log_format_https }}"
        unique-id-format: "{{ haproxy_defaults_unique_id_format }}"
        unique-id-header: "{{ haproxy_defaults_unique_id_header }}"
        option:
          - "forwardfor"
        capture:
          - "request header Host len 60"
          - "request header X-Unique-ID len 46"
          - "request header X-Client-IP len 24"
        reqadd:
          - "X-Forwarded-Proto:\\ {{ haproxy_keystone_admin_frontend_proto }}"
        default_backend: "keystone-admin-backend"

      # copied from role's default
      # KEYSTONE PUBLIC
      - name: "keystone-public"
        mode: http
        bind: "{{ haproxy_keystone_public_frontend_bind }}"
        unique-id-format: "{{ haproxy_defaults_unique_id_format }}"
        unique-id-header: "{{ haproxy_defaults_unique_id_header }}"
        log-format: "{{ haproxy_log_format_https }}"
        option:
          - "forwardfor"
        capture:
          - "request header Host len 60"
          - "request header X-Unique-ID len 46"
          - "request header X-Client-IP len 24"
        reqadd:
          - "X-Forwarded-Proto:\\ {{ haproxy_keystone_public_frontend_proto }}"
        default_backend: "keystone-public-backend"

      # copied from role's default
      # CONSCIENCE
      - name: "conscience"
        mode: tcp
        bind: "{{ haproxy_conscience_frontend_bind }} name conscience"
        log-format: "{{ haproxy_log_format_tcp }}"
        default_backend: "conscience-backend"


keepalived:
  children:
    haproxy: {}
  vars:
    keepalived_vrrp_instances:
      VI_01:
        state: "{{ (groups[keepalived_inventory_groupname][0] == inventory_hostname) | ternary('MASTER', 'BACKUP')}}"
        interface: "{{ openio_bind_interface | d(ansible_default_ipv4.alias) }}"
        virtual_router_id: "{{ openio_vrrp_id | d('57') }}"
        priority: "{{ 150 if groups[keepalived_inventory_groupname][0] == inventory_hostname \
          else 150 - groups[keepalived_inventory_groupname].index(inventory_hostname) }}"
        advert_int: "1"
        authentication:
          auth_type: PASS
          auth_pass: "{{ openio_keepalived_password | d('KEEP_PASS') }}"
        unicast_peer: "{{ groups[keepalived_inventory_groupname] \
          | map('extract', hostvars, ['openio_bind_address']) | list | d([]) }}"
        virtual_ipaddress:
          - "{{ openio_bind_virtual_address }}/{{ openio_bind_virtual_address_mask }} \
              dev {{ openio_bind_interface }} label {{ openio_bind_interface }}:1"
        track_script:
          - check_haproxy
        track_interface:
          - "{{ openio_bind_interface }}"

      # new
      VI_02:
        state: "{{ (groups[keepalived_inventory_groupname][0] == inventory_hostname) | ternary('MASTER', 'BACKUP')}}"
        interface: "{{ openio_bind_virtual_address_external_interface }}"
        virtual_router_id: "{{ openio_bind_virtual_address_external_vrrip }}"
        priority: "{{ 150 if groups[keepalived_inventory_groupname][0] == inventory_hostname \
          else 150 - groups[keepalived_inventory_groupname].index(inventory_hostname) }}"
        advert_int: "1"
        authentication:
          auth_type: PASS
          auth_pass: "{{ openio_keepalived_password | d('KEEP_PASS') }}"
        unicast_peer: "{{ groups[keepalived_inventory_groupname] \
                | map('extract', hostvars, ['ansible_' ~ openio_bind_virtual_address_external_interface, 'ipv4', 'address']) \
                | list }}"
        virtual_ipaddress:
          - "{{ openio_bind_virtual_address_external }}/{{ openio_bind_virtual_address_external_mask }} dev {{ openio_bind_virtual_address_external_interface }} label {{ openio_bind_virtual_address_external_interface }}:1"
        track_script:
          - check_haproxy
        track_interface:
          - "{{ openio_bind_virtual_address_external_interface }}"
```
</p>
</details>

If you have to manage a HTTP proxy, don't forget to add the new VIP to the ``openio_environment``
```yaml
all:
  vars:
    openio_environment: "192.168.1.VIP1,192.168.4.VIP2,,ip_keystone1,ip_keystone2,ip_keystone3"
```

## Monitoring: host distribution

| Function                          | Default groups                    | Override with                                        |
| --------------------------------- | --------------------------------- | ---------------------------------------------------- |
| Admin node (prometheus + grafana) | admin                             | prometheus_admin_hosts                               |
| OIOFS hosts                       | oiofs + oiofs_ha                  | prometheus_oiofs_hosts, openio_netdata_oiofs_hosts   |
| Monitored hosts*                  | fronts + backs + oiofs + oiofs_ha | prometheus_monitored_hosts, openio_netdata_oio_hosts |
| S3 roundtrip hosts                | first and last of fronts          | openio_netdata_s3rt_hosts                            |
| Zookeeper monitored hosts         | zookeeper                         | openio_netdata_zookeeper_hosts                       |
| Redis monitored hosts             | redis                             | openio_netdata_redis_hosts                           |

\* Monitored hosts will have their metrics and healthchecks gathered by Prometheus

## Monitoring: change data retention and path

```yaml
prometheus:
  hosts:
    node1: {}
  vars:
    prometheus_storage_retention: "30d"
    prometheus_storage_path: "/var/lib/prometheus/data"
```

## Monitoring: use a different interface for management

- Data flows are controlled by openio_bind_address
- Admin flows are controlled by openio_bind_mgmt_address
- If not set, all monitoring flows will transit through the data interface

```yaml
openio:
  hosts:
    node1: {}
  vars:
    openio_bind_mgmt_interface: eth1
    #etc.
```

> Note: you can also directly set *openio_bind_mgmt_address* on each host to specify the IP instead of the network

## Monitoring: Make Grafana listen on 0.0.0.0 (or another address)

```yaml
grafana:
  hosts:
    node1: {}
  vars:
    openio_grafana_ext_bind_address: "0.0.0.0"
```

## Monitoring: Configure S3 endpoint for the roundtrip plugin

If your endpoint has been modified, you can customize it as follows:

```yaml
netdata:
  hosts:
    node1: {}
  vars:
    openio_netdata_s3rt_endpoint: "https://s3.example.com"
```

## Download frozen dependencies
In the `requirements.yml`, all openio's building-block are frozen.
```shell
ansible-galaxy install -p roles -r requirements.yml
```

# RUN
## Check connectivity

## Full install
```shell
ansible -i inventory.yml all -m ping
```

### Locks
In order to avoid some surprises in production, we have introduced some locks
* `openio_bootstrap` by default to `false`, it allows to bootstrap the SDS cluster. It is an advanced operation. It is advisable to never version in a file (:bangbang: especially not to true)
* `openio_maintenance_mode` by default to `true`, it allows to restart running services with a new configuration
* `openio_namespace_overwrite` by default to `false`. This file define your namespace on each node. :bangbang: Its modification is an advanced operation

### Deploy and bootstrap SDS
First time only!
```shell
./deploy_and_bootstrap.sh
# or
ansible-playbook -i inventory.yml main.yml -e "openio_bootstrap=true" -e "openio_maintenance_mode=false"
```
### Deploy only
```shell
./deploy.sh
# or
ansible-playbook -i inventory.yml main.yml
```

For subsequent runs, the `openio_maintenance_mode` is set too `true` by default since the 19.04. Files and packages will be put on the nodes but the services will not restart
```shell
ansible-playbook -i inventory.yml main.yml --check
ansible-playbook -i inventory.yml main.yml -e "openio_maintenance_mode=false"
```

## Step-by-step
Selective runs: use the tags to reconfigure specific components
<details><summary>details</summary>
<p>

```console
# grep tags main.yml
  tags: checks
  tags: base
  tags: haproxy
  tags: keepalived
  tags: sds
  tags: db
  tags: keystone
  tags: swift
  tags: post
  tags: inventory
  tags: monitoring
  tags: oiogrid
```
```shell
ansible-playbook -i inventory.yml main.yml -t checks
```
</p>
</details>

You can also directly run the playbook of the component you wish to reconfigure:
```shell
ansible-playbook -i inventory.yml playbooks/haproxy.yml
```
## Dry-run
To run a practice-run you have to add a `--check`to the command
```shell
ansible-playbook -i inventory.yml playbooks/haproxy.yml --check
```

## Asserts resolver
A collection of playbooks are available in `tools/resolver_assert`


## Admin tasks
Current tasks are "ansibled" in the `admin_tasks` folder

---
<a name="OIOFS"></a>
# OIOFS

# Deployment method

All installed services are deployed using Ansible.

# Minimal requirements

## Hardware
* 1 x86_64 node (2 on the same location for HA)
  * 1 CPU
  * 32GB of RAM
  * 2x 10Gbps network devices
  * 8GB of disk space for root / partition
  * 200GB SSD dedicated storage device for OIOFS cache system


## Software
* Ansible 2.5
* python-netaddr
* CentOS 7 (up-to-date)

## Configuration

### Quickstart
 * Edit `inventory.yml`, to add/modify hosts.


### What to modify ?

  * In `inventory.yml`:
    * Change `ansible_host` parameter for all nodes to match your node IPs (must be reachable through SSH from the admin node)
    * Modify the `ansible_user` if necessary to the user used to connect through SSH
    * Add node names in the `oiofs` (`oiofs_ha` for HA) group, and if you need a second redis cluster (different from SDS), fill in the group `redis`
<details><summary>details</summary>
<p>

```yaml
all:
  hosts:
    nodeoiofs:
      ansible_host: 10.0.0.129
      openio_data_mounts: []
      openio_metadata_mounts: []
  vars:
    ansible_user: devops
```
```yaml
all:
  hosts:
    nodeoiofsha1:
      ansible_host: 10.0.0.127
      openio_data_mounts: []
      openio_metadata_mounts: []
      pacemaker_stonith_agent: fence_openstack
      pacemaker_stonith_device:
        pcmk_host_list: "{{ ansible_nodename }}"
        # project name
        project-name: "oiofs"
        auth-url: "http://192.168.1.99:5000"
        passwd: "????"
        project-domain-name: Default
        # user member of the project
        login: "cdelgehier"
        # node1 uuid
        uuid: ca0985fe-f654-408d-b2c9-9ae16a173685

        #pacemaker_stonith_agent: fence_vmware_soap
        #pacemaker_stonith_device:
        #  ipaddr: fr00vce001.cpprod.root.local
        #  ipport: 443
        #  ssl_insecure: 1
        #  ssl: 1
        #  login: 'PROD\srv-opio-prod'
        #  passwd: '&ieKda'
        #  pcmk_host_list: "{{ ansible_nodename }}"

    nodeoiofsha2:
      ansible_host: 10.0.0.126
      openio_data_mounts: []
      openio_metadata_mounts: []
      pacemaker_stonith_agent: fence_openstack
      pacemaker_stonith_device:
        pcmk_host_list: "{{ ansible_nodename }}"
        # project name
        project-name: "oiofs"
        auth-url: "http://192.168.1.99:5000"
        passwd: "???"
        project-domain-name: Default
        # user member of the project
        login: "cdelgehier"
        # node2 uuid
        uuid: 247be896-1db2-488c-a0f7-34b07f8c1991
  vars:
    ansible_user: devops
```
</p>
</details>

  * In the group `openio`:
    * Add groups `oiofs` (`oiofs_ha`) and `oiofs_redis` as children
<details><summary>details</summary>
<p>

```yaml
all:
  children:
    openio:
      children:
        fronts: {}
        backs: {}
        admin: {}
        oiogrid: {}
        oiofs: {}
        #oiofs_ha: {}
        oiofs_redis: {}
```
</p>
</details>
    * Change `oiofs_repo_user` and `oiofs_repo_password` with the provided credentials to access the OIOFS repository. REQUIRED.
<details><summary>details</summary>
<p>

```yaml
all:
  children:
    openio:
      vars:
        openio_repositories_credentials:
          oiofs:
            user: OIOFS_REPO_USER
            password: OIOFS_REPO_PASSWORD
```
</p>
</details>

  * In the groups `ecd`,`namespace`,`oioproxy`:
```yaml
all:
  children:
    …
    ecd:
      hosts:
        nodeoiofsha1: {}
        nodeoiofsha2: {}
        nodeoiofs: {}
    …
    namespace:
      children:
        openio: {}
      hosts:
        #nodeoiofsha1: {}
        #nodeoiofsha2: {}
        nodeoiofs: {}
    …
    oioproxy:
      children:
        openio: {}
      hosts:
        #nodeoiofsha1: {}
        #nodeoiofsha2: {}
        nodeoiofs: {}
```
  * In both groups `oiofs` & `oiofs_ha`:
    * `oiofs_global_mount_directory` defines the directory where the oiofs mounts will be mounted. **TO CUSTOM**
    * `oiofs_global_redis_inventory_groupname` the inventory group of redis to use (WIP). Be careful to change the `redis_sentinel_name` accordingly.
    * `oiofs_global_redis_sentinel_servers` defines redis's IP address. You can specify your own redis sentinels?


    * `oiofs_cache_device` define the dedicated device (`/dev/sdb` by example) used for cache. This device must be already mounted in `oiofs_cache_folder` for the standalone mode. **TO CUSTOM**
    * `oiofs_cache_folder` define the cache folder (:bangbang:: it should already be mounted)
    * `oiofs_cache_low_watermark` and `oiofs_cache_high_watermark` define an acceptable percentage of cache fill


    * `openio_users_add` `openio_users_groups` define users, groups, passwords used for exports **TO CUSTOM**

    * `oiofs_mountpoints` defines the OIOFS mounts that will be accessible through Samba and NFS. **TO CUSTOM**:
      * Modify `namespace`, `account` and `container` accordingly
      * `active_mode`: Must be `true` when using a standalone setup :bangbang: and must be `false` in HA **TO CUSTOM**
      * `openio_sds_conscience_url`: The conscience URL (defined on your OpenIO SDS nodes)
      * `redis_sentinel_servers`: List of 3 IP:port of the Redis Sentinels used by OpenIO SDS
      * `redis_sentinel_name`: REDIS cluster name
      * `http_server`: IP:port used for stats (MUST BE UNIQUE BY MOUNT) :bangbang:


## RUN

  * Prepare your additionals nodes (oiofs and oiofs_ha) and add `ecd`, `namespace` and `oioproxy`:

```shell
ansible all -i inventory.yml -m ping

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml main.yml  -t check,base,ecd,oioproxy,namespace
```
  * Check and install repositories and user on these nodes (Change `playbooks/oiofs_ha.yml` by `playbooks/oiofs.yml` for standalone)
```shell
ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t check

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,repo,user
```

  * Install pacemaker, stonith (mandatory for dlm) and drbd for HA
```shell
ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,pacemaker

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,stonith

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,drbd
```

  * At this point, you must reboot the servers and boot them on the new kernel (with the drbd module)

  * Rerun the `drbd`part
```shell
ansible all -i inventory.yml -m ping

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,drbd
```

  * Deploy the other part for HA
```shell
ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,dlm

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,gfs

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,vip
```

  * Deploy oiofs and exports on these nodes (Change `playbooks/oiofs_ha.yml` by `playbooks/oiofs.yml` for standalone)
```shell
ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,oiofs

ansible-playbook -e "openio_maintenance_mode=false" -i inventory.yml playbooks/oiofs_ha.yml -t facts,exports
```
## Standard Operation Procedures
### Check mounts status

You can check the status with the following commands:
```shell
df -h
gridinit_cmd status @oiofs
```

### How can I check the stack ?
<details><summary>SAMBA</summary>
<p>

```console
[root@node1 ~]# smbstatus

Samba version 4.8.3
PID     Username     Group        Machine                                   Protocol Version  Encryption           Signing
----------------------------------------------------------------------------------------------------------------------------------------

Service      pid     Machine       Connected at                     Encryption   Signing
---------------------------------------------------------------------------------------------

No locked files
```

Checking SAMBA exports:
```shell
smbclient -L <OIOFS_IP> -U <USER_SAMBA>
```
```console
[root@node2 ~]# yum install samba-client
[root@node2 ~]# smbclient -L 172.31.130.18 -U smbguest
Enter WORKGROUP\smbguest's password:

    Sharename       Type      Comment
    ---------       ----      -------
    MY_CONTAINER    Disk      Samba clusterized
    MY_CONTAINER2   Disk      Samba clusterized
    IPC$            IPC       IPC Service (Samba 4.8.3)
Reconnecting with SMB1 for workgroup listing.

    Server               Comment
    ---------            -------

    Workgroup            Master
    ---------            -------
```

Mount cifs on windows
```shell
net use t: \\<OIOFS_IP>\MY_CONTAINER /user:<USER_SAMBA> <USER_SAMBA_PASSWORD>
net use v: \\<OIOFS_IP>\MY_CONTAINER /user:<WORKGROUP>\<USER_AD> <USER_PASSWORD>
```
In case of a mount issue, check permissions: use `chown -R "<WORKGROUP>\\<USER_AD>" /mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER/`

Mount cifs on linux:
```shell
mount -t cifs //<VIP_OIOFS>/MY_CONTAINER /mnt/foo -o username=smbguest,password=samba
```
</p>
</details>

:interrobang: How to fix that windows sees a negative size ?
Set a quota to the desired size on the container `_0` (here: 100 Terabytes)
```shell
openio container set MY_CONTAINER_0 --quota 109951162777600 --oio-ns OPENIO --oio-account MY_ACCOUNT
```
<details><summary>NFS</summary>
<p>

Show NFS exports
```console
# showmount -e <VIP_OIOFS>
Export list for <VIP_OIOFS>:
/mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER *
```

Mount NFS on linux:
```console
# mount -t nfs <VIP_OIOFS>:/mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER /mnt/bar
```
</p>
</details>

Checking gridinit:
```shell
gridinit_cmd status
```
```console
root@node1 ~]# gridinit_cmd status
KEY                                           STATUS      PID GROUP
OPENIO-ecd-0                                  UP        28978 OPENIO,ecd,0
OPENIO-oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER   UP        29839 OPENIO,oiofs,OPENIO-MY_ACCOUNT-MY_CONTAINER
OPENIO-oioproxy-0                             UP        27635 OPENIO,oioproxy,0
```

Checking the addresses:
```shell
ip --color --brief a
```

### How to check if oiofs is master or slave ?
```shell
curl -s 127.0.0.1:6999/conf|jq -r '.active_mode'
```
```console
[root@node1 ~]# curl -s 127.0.0.1:6999/conf|jq -r '.active_mode'
true
```

### How to set oiofs in master mode ?

```shell
curl -v -d '{"active_mode": true}'  127.0.0.1:6999/conf
```
### Check cluster status (HA)
Pacemaker is managing the cluster, you can check the cluster status with the following command:
```shell
pcs status
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha1 ~]# pcs status
Cluster name: 10-0-0-127_10-0-0-126

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: nodeoiofsha1.novalocal (version 1.1.19-8.el7_6.4-c3c624ea3d) - partition with quorum
Last updated: Tue May 28 13:17:28 2019
Last change: Tue May 28 12:08:56 2019 by root via crm_resource on nodeoiofsha2.novalocal

2 nodes configured
24 resources configured

Online: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]

Full list of resources:

 fence_nodeoiofsha1.novalocal	(stonith:fence_openstack):	Started nodeoiofsha2.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Clone Set: gfs2_share-clone [gfs2_share]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 vip-10-0-0-128	(ocf::heartbeat:IPaddr2):	Started nodeoiofsha2.novalocal
 Clone Set: gridinit-clone [gridinit]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Clone Set: gridinit-OPENIO-ecd-0-clone [gridinit-OPENIO-ecd-0]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Clone Set: gridinit-OPENIO-oioproxy-0-clone [gridinit-OPENIO-oioproxy-0]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Master/Slave Set: gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master [gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1]
     Masters: [ nodeoiofsha2.novalocal ]
     Slaves: [ nodeoiofsha1.novalocal ]
 Clone Set: nfs-clone [nfs]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Clone Set: ctdb-clone [ctdb]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Clone Set: samba-clone [samba]
     Started: [ nodeoiofsha1.novalocal nodeoiofsha2.novalocal ]
 Master/Slave Set: gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master [gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2]
     Masters: [ nodeoiofsha2.novalocal ]
     Slaves: [ nodeoiofsha1.novalocal ]

Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled
```
</p>
</details>

Resources should be flagged as Started or Master/Slave.

### Move resources from node to another
You can force a resouce to move from one node to the other.
First, be sure there is no constraint preventing the resource, or a depending resource, to move to the other node.
Check the constraint:
```shell
pcs constraint
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha1 ~]# pcs constraint
Location Constraints:
  Resource: fence_nodeoiofsha1.novalocal
    Disabled on: nodeoiofsha1.novalocal (score:-INFINITY)
Ordering Constraints:
  promote drbd_share-clone then start dlm-clone (kind:Mandatory)
  start dlm-clone then start gfs2_share-clone (kind:Mandatory)
  start gridinit-clone then start gridinit-OPENIO-ecd-0-clone (kind:Mandatory)
  start gridinit-clone then start gridinit-OPENIO-oioproxy-0-clone (kind:Mandatory)
  promote gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master then start vip-10-0-0-128 (kind:Mandatory)
  start gridinit-OPENIO-oioproxy-0-clone then start gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master (kind:Mandatory)
  start gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master then start nfs-clone (kind:Mandatory)
  start gfs2_share-clone then start ctdb-clone (kind:Mandatory)
  start ctdb-clone then start samba-clone (kind:Mandatory)
  promote gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master then start vip-10-0-0-128 (kind:Mandatory)
  start gridinit-OPENIO-oioproxy-0-clone then start gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master (kind:Mandatory)
  start gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master then start samba-clone (kind:Mandatory)
Colocation Constraints:
  dlm-clone with drbd_share-clone (score:INFINITY)
  gridinit-OPENIO-ecd-0-clone with gridinit-clone (score:INFINITY)
  gridinit-OPENIO-oioproxy-0-clone with gridinit-clone (score:INFINITY)
  gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master with gridinit-clone (score:INFINITY)
  vip-10-0-0-128 with gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master (score:INFINITY) (rsc-role:Started) (with-rsc-role:Master)
  vip-10-0-0-128 with nfs-clone (score:INFINITY)
  ctdb-clone with gfs2_share-clone (score:INFINITY)
  samba-clone with ctdb-clone (score:INFINITY)
  gridinit-clone with samba-clone (score:INFINITY)
  vip-10-0-0-128 with samba-clone (score:INFINITY)
  gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master with gridinit-clone (score:INFINITY)
  vip-10-0-0-128 with gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master (score:INFINITY) (rsc-role:Started) (with-rsc-role:Master)
Ticket Constraints:
```
</p>
</details>

```shell
pcs resource move <resource>
```

<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# pcs resource move vip-10-0-0-128 nodeoiofsha1.novalocal
[root@nodeoiofsha2 ~]# pcs constraint
Location Constraints:
  Resource: fence_nodeoiofsha1.novalocal
    Disabled on: nodeoiofsha1.novalocal (score:-INFINITY)
  Resource: vip-10-0-0-128
    Enabled on: nodeoiofsha1.novalocal (score:INFINITY) (role: Started)
Ordering Constraints:
  promote drbd_share-clone then start dlm-clone (kind:Mandatory)
  start dlm-clone then start gfs2_share-clone (kind:Mandatory)
  start gridinit-clone then start gridinit-OPENIO-ecd-0-clone (kind:Mandatory)
  start gridinit-clone then start gridinit-OPENIO-oioproxy-0-clone (kind:Mandatory)
  promote gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master then start vip-10-0-0-128 (kind:Mandatory)
  start gridinit-OPENIO-oioproxy-0-clone then start gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master (kind:Mandatory)
  start gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master then start nfs-clone (kind:Mandatory)
  start gfs2_share-clone then start ctdb-clone (kind:Mandatory)
  start ctdb-clone then start samba-clone (kind:Mandatory)
  promote gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master then start vip-10-0-0-128 (kind:Mandatory)
  start gridinit-OPENIO-oioproxy-0-clone then start gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master (kind:Mandatory)
  start gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master then start samba-clone (kind:Mandatory)
Colocation Constraints:
  dlm-clone with drbd_share-clone (score:INFINITY)
  gridinit-OPENIO-ecd-0-clone with gridinit-clone (score:INFINITY)
  gridinit-OPENIO-oioproxy-0-clone with gridinit-clone (score:INFINITY)
  gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master with gridinit-clone (score:INFINITY)
  vip-10-0-0-128 with gridinit-oiofs-OPENIO_MY_ACCOUNT1_MY_CONTAINER1-master (score:INFINITY) (rsc-role:Started) (with-rsc-role:Master)
  vip-10-0-0-128 with nfs-clone (score:INFINITY)
  ctdb-clone with gfs2_share-clone (score:INFINITY)
  samba-clone with ctdb-clone (score:INFINITY)
  gridinit-clone with samba-clone (score:INFINITY)
  vip-10-0-0-128 with samba-clone (score:INFINITY)
  gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master with gridinit-clone (score:INFINITY)
  vip-10-0-0-128 with gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master (score:INFINITY) (rsc-role:Started) (with-rsc-role:Master)
Ticket Constraints:
```
</p>
</details>

You can clear `contraints` created by the `move`
```shell
pcs resource clear <RESOURCE>
```

<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# pcs constraint location
Location Constraints:
  Resource: fence_nodeoiofsha1.novalocal
    Disabled on: nodeoiofsha1.novalocal (score:-INFINITY)
  Resource: vip-10-0-0-128
    Enabled on: nodeoiofsha1.novalocal (score:INFINITY) (role: Started)

[root@nodeoiofsha2 ~]# pcs resource clear vip-10-0-0-128

[root@nodeoiofsha2 ~]# pcs constraint location
Location Constraints:
  Resource: fence_nodeoiofsha1.novalocal
    Disabled on: nodeoiofsha1.novalocal (score:-INFINITY)
```
</p>
</details>

### How to clean failed actions
If your cluster had failures when operating, you have a small log in a "Failed Actions" section in the cluster status. You can clean this logs using:
```shell
pcs resource cleanup
```
The cluster will clean all resources status and re-monitor them, start them if necessary.

### I have "Failed Actions" but I don't understand what it means ?
You cluster had a failure during an operation on a resource. Let's take an example:
```shell
Failed Actions:
* gridinit-OPENIO-oiofs-mnt_share_oiofs_start_0 on oiofs01.novalocal 'unknown error' (1): call=120, status=complete, exitreason='OPENIO-oiofs-mnt_share_oiofs exists and was DOWN. But it still DOWN',
    last-rc-change='Wed Sep  5 08:31:22 2018', queued=0ms, exec=40ms
```
In this case:
`gridinit-OPENIO-oiofs-mnt_share_oiofs` is the resource that had a failure
`start` is the operation that failed
`oiofs01.novalocal` is the node on which the failure occured
`exitreason='OPENIO-oiofs-mnt_share_oiofs exists and was DOWN. But it still DOWN'`` is the reason

###  My DRBD resource is in Unknown/Standalone state and I can't get my device in sync. What to do ?
You have to disconnect one device (the newest one) and reconnect it telling the cluster this device must be resync. Be aware that you may lose data by doing this !
- Set the cluster in maintenance mode to avoid primary state enforcing
```shell
node1> pcs property set maintenance-mode=true
```
- Set one node in secondary mode and disconnect (eventually)
```shell
node2> drbdadm secondary share
node2> drbdadm disconnect share
```
- Try to reconnect to primary node discarding data (ie: all data on this node will be overwritten)
```shell
node2> drbdadm -- --discard-my-data connect share
```
- On the primary node, refresh the sync:
```shell
node1> drbdadm adjust share
```
- You can check with on both nodes:
```console
node1>  drbdadm status
share role:Primary
  disk:UpToDate
  cplus-oiofs-2.novalocal role:Secondary
    peer-disk:UpToDate

node2> drbdadm status
share role:Secondary
  disk:UpToDate
  cplus-oiofs-1.novalocal role:Primary
    peer-disk:UpToDate
```
-  When the sync is finished, you can set the node primary
```shell
node2> drbdadm primary share
```
- Remove the maintenance mode
```shell
node1> pcs property set maintenance-mode=false
```
- Cleanup error
```shell
node1> pcs resource cleanup
```

### How to get informations about my GFS2 partition ?
```shell
tunegfs2 /dev/drbd0 -l
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# tunegfs2 /dev/drbd0 -l
tunegfs2 (Oct 30 2018 23:29:44)
File system volume name: 10-0-0-127_10-0-0-126:share
File system UUID: b506017d-d247-4642-88ca-7aaa1244ba05
File system magic number: 0x1161970
Block size: 4096
Block shift: 12
Root inode: 4656
Master inode: 2072
Lock protocol: lock_dlm
Lock table: 10-0-0-127_10-0-0-126:share
```
</p>
</details>

### How can I check the stack ?
* Checking DLM:
```shell
dlm_tool status
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# dlm_tool status
cluster nodeid 2 quorate 1 ring seq 36 36
daemon now 63029 fence_pid 0
node 1 M add 56164 rem 0 fail 0 fence 0 at 0 0
node 2 M add 56164 rem 0 fail 0 fence 0 at 0 0
```

(https://fr.slideshare.net/EricRen2/dlm-knowledgesharing)

</p>
</details>

* Checking DRBD:
```shell
drbdadm status
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# drbdadm status
share role:Primary
  disk:UpToDate
  nodeoiofsha1.novalocal role:Primary
    peer-disk:UpToDate
```
</p>
</details>

* SAMBA
  * Checking CTDB:
```shell
ctdb status
ctdb -Y scriptstatus
```

<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# ctdb status
Number of nodes:2
pnn:0 10.0.0.127       OK
pnn:1 10.0.0.126       OK (THIS NODE)
Generation:165468493
Size:2
hash:0 lmaster:0
hash:1 lmaster:1
Recovery mode:NORMAL (0)
Recovery master:0

[root@nodeoiofsha2 ~]# ctdb -Y scriptstatus
00.ctdb              OK         0.006 Tue May 28 13:46:53 2019
01.reclock           OK         0.009 Tue May 28 13:46:53 2019
05.system            OK         0.018 Tue May 28 13:46:53 2019
06.nfs               OK         0.005 Tue May 28 13:46:53 2019
10.external          DISABLED
10.interface         OK         0.010 Tue May 28 13:46:53 2019
11.natgw             OK         0.003 Tue May 28 13:46:53 2019
11.routing           DISABLED
13.per_ip_routing    OK         0.003 Tue May 28 13:46:53 2019
20.multipathd        OK         0.005 Tue May 28 13:46:53 2019
31.clamd             OK         0.004 Tue May 28 13:46:53 2019
40.vsftpd            OK         0.004 Tue May 28 13:46:53 2019
41.httpd             OK         0.003 Tue May 28 13:46:53 2019
49.winbind           OK         0.010 Tue May 28 13:46:53 2019
50.samba             DISABLED
60.nfs               OK         0.006 Tue May 28 13:46:53 2019
70.iscsi             OK         0.003 Tue May 28 13:46:53 2019
91.lvs               OK         0.003 Tue May 28 13:46:53 2019
99.timeout           OK         0.003 Tue May 28 13:46:53 2019
```
</p>
</details>

  * Checking Samba:
```shell
smbstatus
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# smbstatus

Samba version 4.8.3
PID     Username     Group        Machine                                   Protocol Version  Encryption           Signing
----------------------------------------------------------------------------------------------------------------------------------------

Service      pid     Machine       Connected at                     Encryption   Signing
---------------------------------------------------------------------------------------------

No locked files
```
</p>
</details>

  * Checking exports SAMBA:
```shell
smbclient -L <VIP_OIOFS> -U <USER_SAMBA>
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha2 ~]# yum install samba-client -y
[root@nodeoiofsha2 ~]# smbclient -L 10.0.0.128 -U smbguest%samba
    Sharename       Type      Comment
    ---------       ----      -------
    MY_CONTAINER2   Disk      Samba clusterized
    IPC$            IPC       IPC Service (Samba 4.8.3)
Reconnecting with SMB1 for workgroup listing.

    Server               Comment
    ---------            -------

    Workgroup            Master
    ---------            -------
```
</p>
</details>

  * Mount cifs on windows
```shell
net use t: \\<VIP_OIOFS>\MY_CONTAINER /user:<USER_SAMBA> <USER_SAMBA_PASSWORD>
net use v: \\<VIP_OIOFS>\MY_CONTAINER /user:<WORKGROUP>\<USER_AD> <USER_PASSWORD>
```

In case of a mount issue, check permissions: use `chown -R "<WORKGROUP>\\<USER_AD>" /mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER/`

  * How to fix that windows sees a negative size ?
Set a quota to the desired size on the container `_0` (here: 100 Terabytes)
```shell
openio container set MY_CONTAINER_0 --quota 109951162777600 --oio-ns OPENIO --oio-account MY_ACCOUNT
```

  * Mount cifs on linux:
```shell
mount -t cifs //<VIP_OIOFS>/MY_CONTAINER /mnt/foo -o username=smbguest,password=samba
```

* NFS
  * Show NFS exports
```shell
showmount -e <VIP_OIOFS>
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha1 ~]# showmount -e 10.0.0.128
Export list for 10.0.0.128:
/mnt/oiofs-OPENIO-MY_ACCOUNT1-MY_CONTAINER1 *
```
</p>
</details>

  * Mount NFS on linux
```shell
mount -t nfs <VIP_OIOFS>:/mnt/oiofs-OPENIO-MY_ACCOUNT1-MY_CONTAINER1 /mnt/bar
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha1 ~]# mkdir /mnt/bar
[root@nodeoiofsha1 ~]# mount -t nfs 10.0.0.128:/mnt/oiofs-OPENIO-MY_ACCOUNT1-MY_CONTAINER1 /mnt/bar
[root@nodeoiofsha1 ~]# df /mnt/bar/
Sys. de fichiers                                       blocs de 1K Utilisé Disponible Uti% Monté sur
10.0.0.128:/mnt/oiofs-OPENIO-MY_ACCOUNT1-MY_CONTAINER1           0       0          0    - /mnt/bar
```
</p>
</details>

* Checking gridinit:
```shell
gridinit_cmd status
```

<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha1 ~]# gridinit_cmd status
KEY                                           STATUS      PID GROUP
OPENIO-ecd-0                                  UP        16293 OPENIO,ecd,0
OPENIO-oiofs-OPENIO-MY_ACCOUNT1-MY_CONTAINER1 UP        16890 OPENIO,oiofs,OPENIO-MY_ACCOUNT1-MY_CONTAINER1
OPENIO-oiofs-OPENIO-MY_ACCOUNT2-MY_CONTAINER2 UP        31899 OPENIO,oiofs,OPENIO-MY_ACCOUNT2-MY_CONTAINER2
OPENIO-oioproxy-0                             UP        16294 OPENIO,oioproxy,0
```
</p>
</details>

* Checking the VIP is mounted:
```shell
ip --color --brief a
```
<details><summary>details</summary>
<p>

```console
[root@nodeoiofsha1 ~]# ip --color --brief a
lo               UNKNOWN        127.0.0.1/8 ::1/128
eth0             UP             10.0.0.127/8 10.0.0.128/8 fe80::f816:3eff:fe3f:8ea9/64
```
</p>
</details>

### How to disable the cluster ? Stop monitoring to be able to modify the monitored resources ?
```shell
pcs property set maintenance-mode=true
```

### How to re-enable the cluster ?
```shell
pcs property set maintenance-mode=false
```

## Examples

### Inventory

<details><summary>STANDALONE</summary>
<p>

```yaml
---
all:
  hosts:
    …
    nodeoiofs:
      ansible_host: 10.0.0.129
      openio_data_mounts: []
      openio_metadata_mounts: []
    …

  children:
    openio:
      children:
    …
        oiofs: {}
        oiofs_redis: {}
      vars:
    …
        openio_repositories_credentials:
          oiofs:
            user: ????
            password: ????

### SDS
    …
    ecd:
      hosts:
        nodeoiofs: {}
    …
    namespace:
      children:
        openio: {}
      hosts:
        nodeoiofs: {}
    …
    oioproxy:
      children:
        openio: {}
      hosts:
        nodeoiofs: {}
    …
### OIOFS
    oiofs:
      hosts:
        nodeoiofs: {}
      vars:
        oiofs_global_mount_directory: "/mnt"
        #oiofs_global_redis_inventory_groupname: redis  # the same one used for SDS
        oiofs_global_redis_sentinel_servers: "{{ groups[default_oiofs_global_redis_inventory_groupname] \
          | map('extract', hostvars, ['openio_bind_address']) \
          | map('regex_replace', '$', ':6012')
          | list }}"

        ## CACHE
        oiofs_cache_device: /dev/vdb
        oiofs_cache_folder: "{{ oiofs_global_mount_directory }}/cache"
        oiofs_cache_high_watermark: 80
        oiofs_cache_low_watermark: 50

        # USERS
        samba_user_password: samba
        openio_users_add:
          - username: smbguest
            uid: 6000
            name: Samba guest account
            group: smbguest
            groups: []
            home_create: true
            shell: /bin/bash
            update_password: on_create
            password: "{{ samba_user_password | password_hash('sha512')}}"
        openio_users_groups:
          - groupname: smbguest
            gid: 6000

        oiofs_mountpoints:
          - active_mode: true
            namespace: "{{ namespace }}"
            # account/container
            account: MY_ACCOUNT3
            container: MY_CONTAINER3
            state: present
            http_server: 127.0.0.1:6989

            # SDS
            openio_sds_conscience_url: "{{ openio_bind_virtual_address }}:6000"
            oioproxy_url: "{{ openio_bind_address }}:6006"
            ecd_url: "{{ openio_bind_address }}:6017"
            redis_sentinel_servers: "{{ oiofs_global_redis_sentinel_servers }}"
            redis_sentinel_name: "{{ namespace }}-master-1"

            # EXPORTS
            user: root
            group: root
            ignore_flush: true
            auto_retry: false
            export: nfs
            nfs_exports:
             client: "*"
             options:
               - "rw"
               - "async"
               - "no_root_squash"
               - "fsid=1"
             uid: 0
             gid: 0

          - active_mode: true
            namespace: "{{ namespace }}"
            # account/container
            account: MY_ACCOUNT4
            container: MY_CONTAINER4
            state: present
            http_server: 127.0.0.1:6988

            # SDS
            openio_sds_conscience_url: "{{ openio_bind_virtual_address }}:6000"
            oioproxy_url: "{{ openio_bind_address }}:6006"
            ecd_url: "{{ openio_bind_address }}:6017"
            redis_sentinel_servers: "{{ oiofs_global_redis_sentinel_servers }}"
            redis_sentinel_name: "{{ namespace }}-master-1"

            # EXPORTS
            user: smbguest
            group: smbguest
            ignore_flush: true
            auto_retry: false
            export: samba
            samba_exports:
              comment: Samba clusterized
              ? "ea support"
              : "yes"
              export_name: MY_CONTAINER4
              public: "yes"
              ? "read only"
              : "no"
              ? "vfs objects"
              : "catia fruit streams_xattr"
              writeable: "yes"
    …
    oiofs_redis:
      hosts: {}
    …
...

```
</p>
</details>
<details><summary>High Availability</summary>
<p>

```yaml
---
all:
  hosts:
    …
    nodeoiofsha1:
      ansible_host: 10.0.0.127
      openio_data_mounts: []
      openio_metadata_mounts: []
      pacemaker_stonith_agent: fence_openstack
      pacemaker_stonith_device:
        pcmk_host_list: "{{ ansible_nodename }}"
        # project name
        project-name: "oiofs"
        auth-url: "http://192.168.1.99:5000"
        passwd: "???"
        project-domain-name: Default
        # user member of the project
        login: "cdelgehier"
        # node1 uuid
        uuid: ca0985fe-f654-408d-b2c9-9ae16a173685

        #pacemaker_stonith_agent: fence_vmware_soap
        #pacemaker_stonith_device:
        #  ipaddr: fr00vce001.cpprod.root.local
        #  ipport: 443
        #  ssl_insecure: 1
        #  ssl: 1
        #  login: 'PROD\srv-opio-prod'
        #  passwd: '&ieKda'
        #  pcmk_host_list: "{{ ansible_nodename }}"

    nodeoiofsha2:
      ansible_host: 10.0.0.126
      openio_data_mounts: []
      openio_metadata_mounts: []
      pacemaker_stonith_agent: fence_openstack
      pacemaker_stonith_device:
        pcmk_host_list: "{{ ansible_nodename }}"
        # project name
        project-name: "oiofs"
        auth-url: "http://192.168.1.99:5000"
        passwd: "???"
        project-domain-name: Default
        # user member of the project
        login: "cdelgehier"
        # node2 uuid
        uuid: 247be896-1db2-488c-a0f7-34b07f8c1991
    …

  children:
    openio:
      children:
    …
        oiofs_ha: {}
        oiofs_redis: {}

      vars:
    …

        openio_repositories_credentials:
          oiofs:
            user: ????
            password: ????

### SDS
    …
    ecd:
      hosts:
        nodeoiofsha1: {}
        nodeoiofsha2: {}
    …
    namespace:
      children:
        openio: {}
      hosts:
        nodeoiofsha1: {}
        nodeoiofsha2: {}

    …
    oioproxy:
      children:
        openio: {}
      hosts:
        nodeoiofsha1: {}
        nodeoiofsha2: {}
    …
### OIOFS
    oiofs_ha:
      hosts:
        nodeoiofsha1: {}
        nodeoiofsha2: {}
      vars:
        openio_oiofs_bind_virtual_address: "10.0.0.128/8"
        oiofs_global_mount_directory: "/mnt"
        #oiofs_global_redis_inventory_groupname: redis  # the same one used for SDS
        oiofs_global_redis_sentinel_servers: "{{ groups[default_oiofs_global_redis_inventory_groupname] \
          | map('extract', hostvars, ['openio_bind_address']) \
          | map('regex_replace', '$', ':6012')
          | list }}"

        ## CACHE
        oiofs_cache_device: /dev/vdb
        oiofs_cache_folder: "{{ gfs2_mountpoint }}"
        oiofs_cache_high_watermark: 80
        oiofs_cache_low_watermark: 50

        # DRBD
        drbd_netdev: "{{ openio_bind_interface }}"
        drbd_blockdev: "/dev/drbd0"
        drbd_resourcename: share

        # USERS
        samba_user_password: samba

        openio_users_add:
          - username: hacluster
            uid: 189
            name: Pacemaker user
            group: haclient
            groups: []
            home_create: true
            shell: /sbin/nologin
            update_password: on_create
            password: "{{ pacemaker_cluster_auth_password | password_hash('sha512')}}"
          - username: smbguest
            uid: 6000
            name: Samba guest account
            group: smbguest
            groups: []
            home_create: true
            shell: /bin/bash
            update_password: on_create
            password: "{{ samba_user_password | password_hash('sha512')}}"
        openio_users_groups:
          - groupname: haclient
            gid: 189
          - groupname: smbguest
            gid: 6000

        # PACEMAKER
        pacemaker_cluster_auth_username: hacluster
        # TO CUSTOM
        pacemaker_cluster_auth_password: X4MvsACRShL9zUGE

        pacemaker_cluster_netdev: "{{ openio_bind_interface }}"
        ip_ha: "{{ groups['oiofs_ha']  \
          | map('extract', hostvars, ['ansible_' ~ pacemaker_cluster_netdev, 'ipv4', 'address']) \
          | join(' ') }}"
        network_ha: "{{ hostvars[inventory_hostname]['ansible_' ~ pacemaker_cluster_netdev]['ipv4']['network'] }}"
        pacemaker_stonith_enabled: true

        # GFS2
        gfs2_clustered_blockdev: "{{ drbd_blockdev }}"
        gfs2_mountpoint: "/{{ oiofs_global_mount_directory }}/oiofs_cache/{{ drbd_resourcename }}_gfs2"

        oiofs_mountpoints:
          - active_mode: false
            namespace: "{{ namespace }}"
            # account/container
            account: MY_ACCOUNT1
            container: MY_CONTAINER1
            state: present
            http_server: 127.0.0.1:6989

            # SDS
            openio_sds_conscience_url: "{{ openio_bind_virtual_address }}:6000"
            oioproxy_url: "{{ openio_bind_address }}:6006"
            ecd_url: "{{ openio_bind_address }}:6017"
            redis_sentinel_servers: "{{ oiofs_global_redis_sentinel_servers }}"
            redis_sentinel_name: "{{ namespace }}-master-1"

            # EXPORTS
            user: root
            group: root
            ignore_flush: true
            auto_retry: false
            export: nfs
            nfs_exports:
             client: "*"
             options:
               - "rw"
               - "async"
               - "no_root_squash"
               - "fsid=1"
             uid: 0
             gid: 0

          - active_mode: false
            namespace: "{{ namespace }}"
            # account/container
            account: MY_ACCOUNT2
            container: MY_CONTAINER2
            state: present
            http_server: 127.0.0.1:6988

            # SDS
            openio_sds_conscience_url: "{{ openio_bind_virtual_address }}:6000"
            oioproxy_url: "{{ openio_bind_address }}:6006"
            ecd_url: "{{ openio_bind_address }}:6017"
            redis_sentinel_servers: "{{ oiofs_global_redis_sentinel_servers }}"
            redis_sentinel_name: "{{ namespace }}-master-1"

            # EXPORTS
            user: smbguest
            group: smbguest
            ignore_flush: true
            auto_retry: false
            export: samba
            samba_exports:
              comment: Samba clusterized
              ? "ea support"
              : "yes"
              export_name: MY_CONTAINER2
              public: "yes"
              ? "read only"
              : "no"
              ? "vfs objects"
              : "catia fruit streams_xattr"
              writeable: "yes"
    …
    oiofs_redis:
      hosts: {}
    …
...

```
</p>
</details>

## Trouble shooting
### DRDB don't start

__errors__
```shell
TASK [DRBD - Reload if running] *********************************************************************
Friday 18 January 2019  11:22:10 +0000 (0:00:00.677)       0:03:04.709 ********
fatal: [node1]: FAILED! => changed=false
  msg: |-
    Unable to start service drbd: Job for drbd.service failed because the control process exited with error code. See "systemctl status drbd.service" and "journalctl -xe" for details.
fatal: [node2]: FAILED! => changed=false
  msg: |-
    Unable to start service drbd: Job for drbd.service failed because the control process exited with error code. See "systemctl status drbd.service" and "journalctl -xe" for details.
```
__Checks__
```shell
[root@cplus-oiofs-1 ~]# rpm -qa |grep drbd
drbd90-utils-9.6.0-1.el7.elrepo.x86_64
kmod-drbd90-9.0.16-1.el7_6.elrepo.x86_64
[root@cplus-oiofs-1 ~]# rpm -ql kmod-drbd90-9.0.16-1.el7_6.elrepo.x86_64
/etc/depmod.d/kmod-drbd90.conf
/lib/modules/3.10.0-957.el7.x86_64
/lib/modules/3.10.0-957.el7.x86_64/extra
/lib/modules/3.10.0-957.el7.x86_64/extra/drbd90
/lib/modules/3.10.0-957.el7.x86_64/extra/drbd90/drbd.ko
/lib/modules/3.10.0-957.el7.x86_64/extra/drbd90/drbd_transport_tcp.ko
/usr/share/doc/kmod-drbd90-9.0.16
/usr/share/doc/kmod-drbd90-9.0.16/COPYING
/usr/share/doc/kmod-drbd90-9.0.16/ChangeLog
/usr/share/doc/kmod-drbd90-9.0.16/README.md
[root@cplus-oiofs-1 ~]# modprobe drbd
modprobe: FATAL: Module drbd not found.
[root@cplus-oiofs-1 ~]# uname -r
3.10.0-862.14.4.el7.x86_64
```
__Solution__
```shell
[root@cplus-oiofs-1 ~]# reboot
[root@cplus-oiofs-1 ~]# uname -r
3.10.0-957.1.3.el7.x86_64
[root@cplus-oiofs-1 ~]# systemctl start drbd
[root@cplus-oiofs-2 ~]# systemctl start drbd
[root@cplus-oiofs-1 ~]# ll /dev/drbd0
brw-rw---- 1 root disk 147, 0 18 janv. 13:09 /dev/drbd0
[root@cplus-oiofs-1 ~]# drbdadm status
share role:Secondary
  disk:Diskless
  cplus-oiofs-2.novalocal role:Secondary
    peer-disk:Diskless
```

### DRDB `create-md` fails

__errors__

```shell
TASK [DRBD - Initialize the meta data storage] ******************************************************
Friday 18 January 2019  13:34:05 +0000 (0:00:10.314)       0:01:59.485 ********
fatal: [node1]: FAILED! => changed=true
  cmd:
  - drbdadm
  - create-md
  - share
  - --force
  delta: '0:00:00.021221'
  end: '2019-01-18 13:34:06.193128'
  failed_when_result: true
  msg: non-zero return code
  rc: 40
  start: '2019-01-18 13:34:06.171907'
  stderr: Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stderr_lines:
  - Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stdout: |-
    md_offset 16106123264
    al_offset 16106090496
    bm_offset 16105598976

    Found xfs filesystem
        15728640 kB data area apparently used
        15728124 kB left usable by current configuration

    Device size would be truncated, which
    would corrupt data and result in
    'access beyond end of device' errors.
    You need to either
       * use external meta data (recommended)
       * shrink that filesystem first
       * zero out the device (destroy the filesystem)
    Operation refused.
  stdout_lines: <omitted>
fatal: [node2]: FAILED! => changed=true
  cmd:
  - drbdadm
  - create-md
  - share
  - --force
  delta: '0:00:00.020982'
  end: '2019-01-18 13:34:06.225639'
  failed_when_result: true
  msg: non-zero return code
  rc: 40
  start: '2019-01-18 13:34:06.204657'
  stderr: Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stderr_lines:
  - Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stdout: |-
    md_offset 16106123264
    al_offset 16106090496
    bm_offset 16105598976

    Found xfs filesystem
        15728640 kB data area apparently used
        15728124 kB left usable by current configuration

    Device size would be truncated, which
    would corrupt data and result in
    'access beyond end of device' errors.
    You need to either
       * use external meta data (recommended)
       * shrink that filesystem first
       * zero out the device (destroy the filesystem)
    Operation refused.
  stdout_lines: <omitted>
```

__Checks__
```shell
[root@cplus-oiofs-2 ~]# blkid
/dev/vda1: UUID="de86ba8a-914b-4104-9fd8-f9de800452ea" TYPE="xfs"
/dev/vdb: UUID="b7ce58df-ad50-4f51-9d72-82309baf261c" TYPE="xfs"
/dev/vdc: UUID="0c9c4213-4163-4559-befc-42f75c9677f6" TYPE="xfs"
```

__Solution__
```shell
[root@cplus-oiofs-1 ~]#  dd if=/dev/zero of=/dev/vdb
[root@cplus-oiofs-2 ~]#  dd if=/dev/zero of=/dev/vdb
[root@cplus-oiofs-2 ~]# blkid
/dev/vda1: UUID="de86ba8a-914b-4104-9fd8-f9de800452ea" TYPE="xfs"
/dev/vdc: UUID="0c9c4213-4163-4559-befc-42f75c9677f6" TYPE="xfs"
```

### GFS2 not found
__errors__
```shell
TASK [Fail if GFS2 path is not a valid block device] ************************************************
Friday 18 January 2019  16:14:04 +0000 (0:00:00.252)       0:02:23.645 ********
fatal: [node1]: FAILED! => changed=false
  msg: Source block device "/dev/drbd0" for GFS2 not found.
fatal: [node2]: FAILED! => changed=false
  msg: Source block device "/dev/drbd0" for GFS2 not found.
```

__Checks__
```shell
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:29:33 2019
Last change: Fri Jan 18 16:14:04 2019 by root via cibadmin on cplus-oiofs-1.novalocal

2 nodes configured
6 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Stopped: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Stopped: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Failed Actions:
* drbd_share_start_0 on cplus-oiofs-1.novalocal 'not configured' (6): call=17, status=complete, exitreason='',
    last-rc-change='Fri Jan 18 16:14:02 2019', queued=0ms, exec=31ms
```

__Solution__
```shell
[root@cplus-oiofs-1 ~]# pcs resource cleanup
Cleaned up all resources on all nodes
Waiting for 1 replies from the CRMd. OK
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:29:49 2019
Last change: Fri Jan 18 16:29:47 2019 by hacluster via crmd on cplus-oiofs-1.novalocal

2 nodes configured
6 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     dlm    (ocf::pacemaker:controld):    Starting cplus-oiofs-1.novalocal
     Stopped: [ cplus-oiofs-2.novalocal ]

Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:29:59 2019
Last change: Fri Jan 18 16:29:47 2019 by hacluster via crmd on cplus-oiofs-1.novalocal

2 nodes configured
6 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled

[root@cplus-oiofs-1 ~]# drbdadm status
share role:Primary
  disk:UpToDate
  cplus-oiofs-2.novalocal connection:StandAlone

```

### /dev/drbd0 doesn't mount
__errors__
```shell
TASK [GFS - Wait for Pacemaker to start the resource] ***********************************************
Friday 18 January 2019  16:33:37 +0000 (0:00:00.379)       0:02:03.016 ********
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (20 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (20 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (19 retries left).
changed: [node1]
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (18 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (17 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (16 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (15 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (14 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (13 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (12 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (11 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (10 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (9 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (8 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (7 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (6 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (5 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (4 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (3 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (2 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (1 retries left).
fatal: [node2]: FAILED! => changed=true
  attempts: 20
  cmd: mount|grep '^/dev/drbd0 on'|awk '{print $3}'
  delta: '0:00:00.003981'
  end: '2019-01-18 16:35:40.902724'
  failed_when_result: true
  rc: 0
  start: '2019-01-18 16:35:40.898743'
  stderr: ''
  stderr_lines: []
  stdout: ''
  stdout_lines: <omitted>
```

__Checks__
```shell
[root@cplus-oiofs-1 ~]#  pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:36:59 2019
Last change: Fri Jan 18 16:33:37 2019 by root via cibadmin on cplus-oiofs-1.novalocal

2 nodes configured
8 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: gfs2_share-clone [gfs2_share]
     Started: [ cplus-oiofs-1.novalocal ]
     Stopped: [ cplus-oiofs-2.novalocal ]

Failed Actions:
* gfs2_share_start_0 on cplus-oiofs-2.novalocal 'unknown error' (1): call=35, status=complete, exitreason='Couldn't mount device [/dev/drbd0] as /mnt/share_gfs2',
    last-rc-change='Fri Jan 18 16:33:36 2019', queued=0ms, exec=73ms


Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled

[root@cplus-oiofs-1 ~]# tail -f /var/log/message &
   ... drbd share/0 drbd0: Split-Brain detected but unresolved, dropping connection!

[root@cplus-oiofs-1 ~]# drbdadm adjust share

```

__Solution__
Check the `My DRBD resource is in Unknown/Standalone state and I can't get my device in sync. What to do ?` paragraph

### My user Active Directory fails to access the samba export

__errors__

![Samba error permission](../archives/oiofs_ha/samba_error_permission.png)


__Checks__
```console
[root@cplus-oiofs2 ~]# ls -al /mnt/oiofs* -d
drwxr-xr-x 6 root        root               135 27 févr. 22:46 /mnt/oiofs_cache
drwxr-x--- 1 root        root              4096 28 févr. 12:23 /mnt/oiofs-OPENIO-act1-cont1
drwxr-x--- 1 smbguest    smbguest          4096 22 févr. 20:22 /mnt/oiofs-OPENIO-act2-cont2
drwxr-x--- 1 CPLUS\user1 CPLUS\my_ad_group 4096 27 févr. 22:46 /mnt/oiofs-OPENIO-act3-cont3
```
`/mnt/oiofs-OPENIO-act1-cont1` is owned by root

__Solution__

Change permisions on both servers
```shell
[root@cplus-oiofs2 ~]# id CPLUS\\user1
uid=3000(CPLUS\user1) gid=3007(CPLUS\domain users) groupes=3007(CPLUS\domain users),3008(CPLUS\my_ad_group),3009(CPLUS\group1),3003(BUILTIN\users)

[root@cplus-oiofs2 ~]# chown CPLUS\\user1 /mnt/oiofs-OPENIO-act1-cont1/
[root@cplus-oiofs2 ~]# chgrp CPLUS\\my_ad_group /mnt/oiofs-OPENIO-act1-cont1/

[root@cplus-oiofs2 ~]# ls -al /mnt/oiofs* -d
drwxr-xr-x 6 root        root               135 27 févr. 22:46 /mnt/oiofs_cache
drwxr-x--- 1 CPLUS\user1 CPLUS\my_ad_group 4096 28 févr. 12:23 /mnt/oiofs-OPENIO-act1-cont1
drwxr-x--- 1 smbguest    smbguest          4096 22 févr. 20:22 /mnt/oiofs-OPENIO-act2-cont2
drwxr-x--- 1 CPLUS\user1 CPLUS\my_ad_group 4096 27 févr. 22:46 /mnt/oiofs-OPENIO-act3-cont3

```

### my samba can not register to the Active Directory

__errors__
```console
TASK [samba : Add node to Active Directory] *************************************************************
Thursday 28 February 2019  10:03:38 +0000 (0:00:02.190)       0:00:23.909 *****
failed: [node1]
```


__Checks__
```shell
net ads join -U 'Administrator%Admin_AD_Password'
```

__Solution__

Check IP address, user Administrator, WORKGROUP and DOMAIN on the AD server.
```console
C:\Users\openio>Net Config Workstation
Computer name                        \\WIN2016
Full Computer name                   win2016.cplus.oio
User name                            openio

Workstation active on
        NetBT_Tcpip_{2E871AAA-CCF8-4A79-902F-675ADDE3FD43} (FA163E1A3663)
        NetBT_Tcpip_{B8A56940-05EC-428F-BA5F-8C447B7BF63D} (FA163EF5FFAE)

Software version                     Windows Server 2016 Standard Evaluation

Workstation domain                   CPLUS       <- WORKGROUP
Workstation Domain DNS Name          cplus.oio   <- domain
Logon domain                         CPLUS

COM Open Timeout (sec)               0
COM Send Count (byte)                16
COM Send Timeout (msec)              250
The command completed successfully.
```

```yaml
openio_samba_active_directory:
  nameserver_address: 172.31.130.25
  domain_name: "cplus.oio"
  workgroup: "CPLUS"
  admin: "Administrator"
  password: "fooBar1!"
  samba_address: "{{ hostvars[inventory_hostname]['ansible_' ~ openio_bind_interface]['ipv4']['address'] }}"
  id_range: "3000-7999"
```
## Cluster view

![OIOFS HA - Cluster View](../archives/oiofs_ha/oiofs_ha_cluster_view.png)

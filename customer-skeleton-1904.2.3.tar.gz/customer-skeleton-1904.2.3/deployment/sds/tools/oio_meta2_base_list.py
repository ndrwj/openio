import requests
import logging as log
import sys
from argparse import ArgumentParser


class OioMeta2BaseList(object):
    """
    Class implementing the meta2 base list function
    """

    def __init__(self):
        parser = ArgumentParser(
            description='List bases that have been handled by a meta2 service'
        )
        parser.add_argument('meta2', help='IP:PORT of a meta2 service')
        parser.add_argument('-o', '--out', help='Output to file')
        parser.add_argument('-c', '--conscience',
                            help='IP:PORT of a consience service',
                            required=True)
        parser.add_argument('-a', '--account',
                            help='IP:PORT of an account service',
                            required=True)
        parser.add_argument('-n', '--namespace',
                            default='OPENIO', help='OpenIO namespace')
        parser.add_argument('-v', '--debug',
                            help='Verbose mode', action='store_true')
        self.args = parser.parse_args()

        self.cons_url = "http://%s" % self.args.conscience
        self.acct_url = "http://%s" % self.args.account

        log.basicConfig(level=log.DEBUG if self.args.debug else log.INFO)

        self.search()

    def err(self, msg):
        log.error(msg)
        sys.exit(1)

    def search(self):
        last = None

        res = requests.get("%s/v1.0/account/list" % self.acct_url)
        if res.status_code / 100 != 2:
            self.err('Failed to get account list: HTTP %s' % res.status_code)

        if self.args.out:
            with open(self.args.out, 'wb') as f:
                f.write("")

        for acct in res.json():
            log.debug('=== Acct %s ===' % acct)
            while last is not False:
                res = requests.get(
                    "%s/v1.0/account/containers?id=%s&limit=1000&marker=%s"
                    % (self.acct_url, acct, last))
                if res.status_code / 100 != 2:
                    self.err('Failed to get containers: HTTP %s'
                             % res.status_code)

                listing = res.json()['listing']
                if len(listing) == 0:
                    last = False

                for cont in listing:
                    res = requests.get(
                        "%s/v3.0/%s/container/list\
?acct=%s&ref=%s&properties=False"
                        % (self.cons_url, self.args.namespace, acct, cont[0])
                    )
                    if res.status_code / 100 != 2:
                        self.err(
                            'Cannot retrieve container info: HTTP %s'
                            % res.status_code
                        )
                    data = res.json()['system']

                    if self.args.meta2 in data['sys.peers'].split(','):
                        if self.args.out:
                            with open(self.args.out, 'a') as f:
                                f.write(data['sys.name'] + "\n")
                        else:
                            print data['sys.name']
                    last = cont[0]


OioMeta2BaseList()

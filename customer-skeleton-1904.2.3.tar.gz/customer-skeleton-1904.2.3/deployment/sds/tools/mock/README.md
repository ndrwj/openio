# optional - edit the key
`cat id_rsa.pub`

# centos
`docker build -t centos7_sshd  -f Dockerfile_c7 .`

# xenial
`docker build -t xenial_sshd  -f Dockerfile_u16 .`

# bionic
`docker build -t bionic_sshd  -f Dockerfile_u18 .`

./spawn_env.sh

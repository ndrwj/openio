#!/usr/bin/env python

from __future__ import print_function

import argparse
import os
import sys
import time
from xml.etree import ElementTree as ET

import requests


def options(args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cosbench-url",
        help="URL of cosbench", default="http://127.0.0.1:19088")
    parser.add_argument(
        "--cosbench-user",
        help="User of cosbench", default="")
    parser.add_argument(
        "--cosbench-pass",
        help="Password of cosbench", default="")
    parser.add_argument(
        "scenario",
        help="File of scenario to submit")
    opts = parser.parse_args(args)
    return opts


class CosError(Exception):
    pass


class CosbenchRun(object):
    def __init__(self, opts):
        self.id = None
        self.scenario = opts.scenario
        self._check_xml()
        if not opts.cosbench_url.startswith('http'):
            raise CosError("Please prefix URL with http:// or https://")
        self._url = {'url': opts.cosbench_url,
                     'user': opts.cosbench_user,
                     'pass': opts.cosbench_pass}

    def _check_xml(self):
        if not os.path.isfile(self.scenario):
            raise CosError("Scenario not found, aborting")
        try:
            ET.parse(self.scenario)
        except ET.ParseError:
            raise CosError("Scenario is not a valid XML")

    def url(self, action):
        return "{url}/controller/cli/{action}?username=${user}&password={pass}".format( # noqa
            action=action, **self._url)

    def launch(self):
        url = self.url("submit.action")
        ret = requests.post(url, files={"config": open(self.scenario)})
        data = ret.text
        if not data.startswith('Accepted') or ret.status_code // 100 != 2:
            raise CosError("Failed to submit scenario: %s" % data)
        self.id = data.split(':')[1].strip()
        print("Scenario %s submitted as %s" % (
            os.path.basename(self.scenario), self.id))

    def wait(self):
        url = self.url("workload.action") + '&id=%s' % self.id
        while True:
            ret = requests.get(url)
            if 'PROCESSING' not in ret.text:
                break
            time.sleep(5)
        if 'FINISHED' not in ret.text:
            raise CosError("Scenario has failed with error: %s" % ret.text)
        print("Scenario finished successfully")


if __name__ == "__main__":
    opts = options(sys.argv[1:])
    run = CosbenchRun(opts)
    run.launch()
    run.wait()

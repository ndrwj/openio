#!/bin/bash
#
#
##############################################################
# Administration script for keystone user creation
# Set variables, project, user, password
##############################################################
#set -x

usage()
{
        echo "Usage:" 1>&2
        echo "$0 [-h] [-e keystone_auth_url -P <project_name>] [-u <user_name>] [-p <password>]" 1>&2
        echo "       -h, Print detailed help screen" 1>&2
        echo "       -e, keystone auth url ex: http://10.0.0.1" 1>&2
        echo "       -P, keystone project name" 1>&2
        echo "       -u, keystone user name, must be alphanumeric" 1>&2
        echo "       -p, password for your keystone user " 1>&2
        echo "" 1>&2
}

if [[ "$(pwd)" != "/root/scripts" ]]; then
    echo
    echo "Bad path !"
    echo "You must create /root/scripts directory and"
    echo "run me in /root/scripts"
    echo
    exit 1
fi

#check argument
if [ "$#" -eq 0 ]; then
    echo
    echo "We need arguments"
    echo
    usage
    exit
fi

while getopts "he:P:u:p:" option
do
  case $option in
    h)
      echo "-h was triggered, Parameter: $OPTARG" >&2
      usage; exit 2
      ;;
    e)
      echo "-e was triggered, Parameter: $OPTARG" >&2
      keystone_auth_url=$OPTARG
      if [[ $OPTARG =~ ^http:// ]]; then
          keystone_auth_url=$OPTARG
      else
          echo
          echo "keystone auth url must begin with http://"  
          echo
          exit 1
      fi
      ;;
    P)
      echo "-P was triggered, Parameter: $OPTARG" >&2
      keystone_project=$OPTARG
      ;;
    u)
      echo "-u was triggered, Parameter: $OPTARG" >&2
      keystone_user=$OPTARG
      if [[ $OPTARG =~ ^[A-Za-z0-9]+$ ]]; then
          keystone_user=$OPTARG
      else
          echo
          echo "user must only contains alphanumeric caractere"
          echo
          exit 1
      fi
      ;;
    p)
      echo "-p was triggered, Parameter: $OPTARG" >&2
      keystone_password=$OPTARG
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
    :)
      echo "Option -$OPTARG requires an argument." >&2
      exit 1
      ;;
  esac
done

if [[ -z ${keystone_auth_url} || -z ${keystone_user} || -z ${keystone_password} || -z ${keystone_project} ]]
then
	echo
	echo "Please fill all required field"
	echo
        usage
	exit 1
fi

echo "Creating user (${keystone_user}) whith password (${keystone_password}) for project (${keystone_project})"
read -p "Are you sure (y/n)? " answer
case ${answer:0:1} in
    y|Y )
        echo Yes
    ;;
    * )
        echo No
	exit 1
    ;;
esac


#Check admin credentials exist
#if [ ! -e /root/scripts/.users/.keystone_admin ]
#then
#    echo "Could not find admin credentials"
#    echo "Abort..."
#    exit 1
#fi

#source admin credentials
#source /root/scripts/.users/.keystone_admin
mkdir -p /root/scripts/.users >/dev/null

#Create new project/user
echo "Create project: ${keystone_project}"
openstack --os-cloud openio project create "${keystone_project}"
echo "Create user: ${keystone_user}"
openstack --os-cloud openio user create --password "${keystone_password}" --project "${keystone_project}" ${keystone_user}
echo "Add ${keystone_user} to role _member_"
openstack --os-cloud openio role add --user "${keystone_user}" --project "${keystone_project}" _member_

unset OS_PROJECT_NAME
unset OS_USERNAME
unset OS_PASSWORD

echo "export OS_PROJECT_DOMAIN_NAME=Default
export OS_USER_DOMAIN_NAME=Default
export OS_PROJECT_NAME=${keystone_project}
export OS_USERNAME=${keystone_user}
export OS_PASSWORD=\"${keystone_password}\"
export OS_IDENTITY_API_VERSION=3
export OS_IMAGE_API_VERSION=2
export OS_AUTH_URL=${keystone_auth_url}:35357" > /root/scripts/.users/.keystone_${keystone_user}

echo "Create credentials for user ${keystone_user} linked to project ${keystone_project}"
#set new user var
source /root/scripts/.users/.keystone_${keystone_user}

#create s3 credentials
openstack ec2 credentials create

#Check s3 credentials
openstack ec2 credentials list

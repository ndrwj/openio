# Admin Tasks

This folder contains admin tasks playbooks.

# Dashboard Integration

The dashboard loads admin tasks definitions from the `definitions.yml` file.
This file contains the template definitions for running tasks.

### Template Definition

Fields:

* `name` - Template name
* `playbook` - Path to playbook in project.
* `job_spec` - Job Spec

### Job Spec

Fields:

* `name` - Display name
* `description` - Description text
* `group` - Display group
* `variables` - Spec

### Variable Spec

The spec defines variables to run the task.

Here are the fields for a variable:

* `name` - Display name
* `variable` - Ansible variable name
* `type` - Variable type
* `default` - Default value
* `required` - Whether the variable is required.

**TYPE**

Available types:

- `boolean` - Boolean
- `text` - String
- `integer` - Integer


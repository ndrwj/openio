#!/bin/bash
ansible-galaxy install -p roles -r requirements.yml $*

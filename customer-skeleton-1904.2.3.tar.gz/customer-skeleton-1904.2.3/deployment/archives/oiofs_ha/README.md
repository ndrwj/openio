# OIOFS HA

# Deployment method

All installed services are deployed using Ansible.

# Minimal requirements

## Hardware
* 2 x86_64 nodes on a same site
  * 1 CPU
  * 32GB of RAM
  * 2x 10Gbps network devices
  * 8GB of disk space for root / partition
  * 200GB SSD dedicated storage device for OIOFS cache system
  * BMC with on/off/reboot capability from each node

### BMC tips
* VMWare: VM have to join esxi or vcenter on its SSL port
* VMWare: The vCentre account which we use above has “Power On/Power Off” privileges on VMware and is allowed to access all machines that we use in the series.
* VMWare: [What user permissions/roles are required for the VMware vCenter user account to perform fence action using fence_vmware_soap ?](https://access.redhat.com/solutions/82333)
```
In order to allow fence_vmware_soap to work, the configured vCenter user account needs to belong to a role with the following four permissions set in vSphere:

System.Anonymous
System.View
VirtualMachine.Interact.PowerOff
VirtualMachine.Interact.PowerOn
The first role is created for the user automatically, as is the second role once you've created a user that's allowed to login to vSphere. That just leaves the other two that would need to be added to the user account.

```
## Software
* Ansible 2.5
* python-netaddr
* CentOS 7 (up-to-date) for both nodes

## Download and set playbook

Follow the commands below to install OpenIO OIOFS High Availability, on admin node :

```
# git clone git@github.com:open-io/customer-[ Customer ].git
# cd  customer-[ Customer ] /deployment/oiofs_ha
```
Download all requirements on, roles directory.
`ansible-galaxy install -p roles -r requirements.yml`

## Configuration

### Quickstart
 * Edit `inventory.ini`, to add/modify hosts.
 * Edit `group_vars/oiofs_ha.yml` to customize your deployment
 * Edit `group_vars/openio.yml` to customize your SDS backend
 * Edit `host_vars/node*.yml` to customize data and metadata location

### What to modify ?

  * In `inventory.ini`:
    * Change `ansible_host` parameter for node1 and node2 to match your node IPs (must be reachable through SSH from the admin node)
    * Modify the `ansible_user` if necessary to the user used to connect through SSH
    * Add node names in the `oiofs_ha` group, and if you need a second redis cluster (different from SDS), fill in the group `redis`

  * In `group_vars/openio.yml`:
    * Modify `openio_release` if required
    * Modify `namespace` to match the namespace used by SDS
    * Modify the `openio_bind_interface` parameter according to the production network device that will be used to connect to OIOFS (place this parameter in `host_vars/nodeX.yml` if network devices are different). REQUIRED.
    * `openio_bind_virtual_address` define the Virtual IP address of SDS
    * `openio_oiofs_bind_virtual_address` define the Virtual IP address of oiofs
    * Change `oiofs_repo_user` and `oiofs_repo_password` with the provided credentials to access the OIOFS repository. REQUIRED.

  * In `group_vars/oiofs_ha.yml`:
  * `oiofs_global_mount_directory` defines the directory where the oiofs mounts will be mounted.
  * `oiofs_global_redis_sentinel_servers` defines redis's IP address.
  * `openio_users_add` `openio_users_groups` define users, groups, passwords used for exports
  * `oiofs_mountpoints` defines the OIOFS mounts that will be accessible through Samba. REQUIRED:
    * Modify `namespace`, `account` and `container` accordingly
    * `active_mode`: Must be `false` when using HA
    * `openio_sds_conscience_url`: The conscience URL (defined on your OpenIO SDS nodes)
    * `oioproxy_url`: OIOProxy url
    * `ecd_url`: ECD url
    * `redis_sentinel_servers`: List of 3 IP:port of the Redis Sentinels used by OpenIO SDS
    * `redis_sentinel_name`: REDIS cluster name
    * `vip`: Virtual IP used to access the OIOFS HA service
    * `cache_directory`: OIOFS cache directory. Should be the same (or a subdirectory of) as `gfs2_mountpoint` (see below)
    * `pacemaker_cluster_auth_username`: Login to connect to the Pacemaker cluster. `hacluster` by default
    * `pacemaker_cluster_auth_password`. Password to connect to the Pacemaker cluster. REQUIRED.
    * `pacemaker_cluster_netdev`: Pacemaker network device
    * `drbd_netdev`: Network device to use for DRBD block replication
    * `drbd_blockdev`: DRBD block device exposed. Default to `/dev/drbd0` if no other DRBD device is used on nodes.
    * `oiofs_cache_device` define the dedicated device used for cache
    * `oiofs_cache_folder` define the already mounted cache folder
    * `oiofs_cache_low_watermark` and `oiofs_cache_high_watermark` define an acceptable percentage of cache fill
    * `drbd_resourcename`: DRBD resource name. Should be modified accordingly with `cache_directory` and `gfs2_mountpoint`
    * `gfs2_clustered_blockdev`: GFS2 block device used, must be the same as `drbd_blockdev`
    * `gfs2_mountpoint`: GFS2 exposed mountpoint. Should be modified accordingly with `cache_directory` and `gfs2_mountpoint`


  * Configure the fencing in `host_vars/node1.yml` and `host_vars/node2.yml`:
    * `pacemaker_stonith_agent`: STONITH agent to use (could be one of `fence_openstack`, `fence_vmware_soap` or `fence_ipmilan` depending on your BMC). REQUIRED.
    * `pacemaker_stonith_device`: Configuration of the STONITH resource. REQUIRED:
      * `pcmk_host_list`: FQDN of the node controlled by the resource. Default to `"{{ ansible_nodename }}"`
      * Depending on the Pacemaker STONITH agent configured, configure using the [documentation](https://github.com/ClusterLabs/fence-agents/tree/master/agents)

```yaml
# OpenStack
pacemaker_stonith_agent: fence_openstack
pacemaker_stonith_device:
  pcmk_host_list: "{{ ansible_nodename }}"
  project-name: "customer-canal"
  auth-url: "http://192.168.1.99:5000"
  passwd: "..."
  project-domain-name: Default
  login: "fence_user_canal_plus"
  # cplus_oiofs_1
  uuid: f0085cff-bb47-4567-98cb-e0e10f346b24
```

```yaml
# VmWare
pacemaker_stonith_agent: fence_vmware_soap
pacemaker_stonith_device:
  pcmk_host_list: "{{ ansible_nodename }}"
  ipaddr: frcp00vce001.cpprod.root.local
  ipport: 443
  ssl_insecure: 1
  ssl: 1
  login: 'CPPROD\srv-opio-prod'
  passwd: '...'
```

## RUN

### Deployment
  * Step-by-step Deployment

```shell
# Cluster, fence
ansible-playbook -i inventory.ini main.yml -t pacemaker
# gridinit, namepsace, ecd, oiofs
ansible-playbook -i inventory.ini main.yml -t namespace
# samba, nfs, ftp
ansible-playbook -i inventory.ini main.yml -t exports
# mounts
ansible-playbook -i inventory.ini main.yml -t mounts
```
List of tags:
```shell
ansible-playbook -i inventory.ini  main.yml --list-tags
#or
grep tag main.yml
```
  * Full install `ansible-playbook -i inventory.ini main.yml`

### Mounts
```yaml
oiofs_mountpoints:
  - active_mode: false
    namespace: OPENIO
    # account/container
    account: act1
    container: cont1
    state: present
    #VIP sds
    openio_sds_conscience_url: "{{ openio_bind_virtual_address }}:6000"
    oioproxy_url: "{{ hostvars[inventory_hostname]['ansible_' ~ openio_bind_interface]['ipv4']['address'] }}:6006"
    ecd_url: "{{ hostvars[inventory_hostname]['ansible_' ~ openio_bind_interface]['ipv4']['address'] }}:6017"
    redis_sentinel_servers: "{{ oiofs_global_redis_sentinel_servers }}"
    redis_sentinel_name: "OPENIO-master-1"  # Default to NAMESPACE-master-1
    #VIP oiofs
    vip: "{{ openio_oiofs_bind_virtual_address }}"  # CIDR
    cache_directory: "{{ oiofs_cache_folder }}"
    http_server: 127.0.0.1:6999  # must be unique by mount
    # EXPORTS
    user: smbguest  # set uid/gid samba
    group: smbguest
    ignore_flush: true  # NFS
    auto_retry: false   # NFS
    exports: nfs
    nfs_exports:
      client: "*"
      options:
        - "rw"
        - "async"
        - "all_squash"
        # must be different by mountpoint
        - "fsid=1"
      uid: 6000 # must be identical to smbguest
      gid: 6000 # must be identical to smbguest

  - active_mode: false
    namespace: OPENIO
    # account/container
    account: act2
    container: cont2
    state: present
    #VIP sds
    openio_sds_conscience_url: "{{ openio_bind_virtual_address }}:6000"
    oioproxy_url: "{{ hostvars[inventory_hostname]['ansible_' ~ openio_bind_interface]['ipv4']['address'] }}:6006"
    ecd_url: "{{ hostvars[inventory_hostname]['ansible_' ~ openio_bind_interface]['ipv4']['address'] }}:6017"
    redis_sentinel_servers: "{{ oiofs_global_redis_sentinel_servers }}"
    redis_sentinel_name: "OPENIO-master-1"  # Default to NAMESPACE-master-1
    #VIP oiofs
    vip: "{{ openio_oiofs_bind_virtual_address }}"  # CIDR
    cache_directory: "{{ oiofs_cache_folder }}"
    http_server: 127.0.0.1:6998  # must be unique by mount
    # EXPORTS
    user: smbguest
    group: smbguest
    ignore_flush: true   # SAMBA
    exports: samba
    samba_exports:
      comment: Samba clusterized
      ? "ea support"
      : "yes"
      export_name: MY_CONTAINER6
      public: "yes"
      ? "read only"
      : "no"
      ? "vfs objects"
      : "catia fruit streams_xattr"
      writeable: "yes"
```
Change the `state` to `absent` to remove the filesystem oiofs (gridinit, pacemaker)

## Control

Follow : https://github.com/open-io/customer-[ Customer ]/tree/master/deployment/sds/testing

## Cluster view

![OIOFS HA - Cluster View](oiofs_ha_cluster_view.png)

## Standard Operation Procedures
### Check cluster status
Pacemaker is managing the cluster, you can check the cluster status with the following command:
```shell
pcs status
```
Resources should be flagged as Started or Master/Slave.

### Move resources from node to another
You can force a resouce to move from one node to the other.
First, be sure there is no constraint preventing the resource, or a depending resource, to move to the other node.
Check the constraint:
```shell
pcs constraint
```

```shell
pcs resource move <resource>
```

### How to clean failed actions
If your cluster had failures when operating, you have a small log in a "Failed Actions" section in the cluster status. You can clean this logs using:
```shell
pcs resource cleanup
```
The cluster will clean all resources status and re-monitor them, start them if necessary.

### I have "Failed Actions" but I don't understand what it means ?
You cluster had a failure during an operation on a resource. Let's take an example:
```shell
Failed Actions:
* gridinit-OPENIO-oiofs-mnt_share_oiofs_start_0 on oiofs01.novalocal 'unknown error' (1): call=120, status=complete, exitreason='OPENIO-oiofs-mnt_share_oiofs exists and was DOWN. But it still DOWN',
    last-rc-change='Wed Sep  5 08:31:22 2018', queued=0ms, exec=40ms
```
In this case:
`gridinit-OPENIO-oiofs-mnt_share_oiofs` is the resource that had a failure
`start` is the operation that failed
`oiofs01.novalocal` is the node on which the failure occured
`exitreason='OPENIO-oiofs-mnt_share_oiofs exists and was DOWN. But it still DOWN'`` is the reason

###  My DRBD resource is in Unknown/Standalone state and I can't get my device in sync. What to do ?
You have to disconnect one device (the newest one) and reconnect it telling the cluster this device must be resync. Be aware that you may lose data by doing this !
- Set the cluster in maintenance mode to avoid primary state enforcing
```shell
pcs property set maintenance-mode=true
```
- Set one node in secondary mode and disconnect (eventually)
```shell
drbdadm secondary share
drbdadm disconnect share
```
- Try to reconnect to primary node discarding data (ie: all data on this node will be overwritten)
```shell
drbdadm -- --discard-my-data connect share
```
- On the primary node, refresh the sync:
```shell
drbdadm adjust share
```
- You can check with on both nodes:
```console
[root@cplus-oiofs-1 ~]# drbdadm status
share role:Primary
  disk:UpToDate
  cplus-oiofs-2.novalocal role:Secondary
    peer-disk:UpToDate
```
-  When the sync is finished, you can set the node primary
```shell
drbdadm primary share
```
- Remove the maintenance mode
```shell
pcs property set maintenance-mode=false
```
- Cleanup error
```shell
pcs resource cleanup
```

### How to get informations about my GFS2 partition ?
```shell
tunegfs2 /dev/drbd0 -l
```

### How can I check the stack ?
Checking DLM:
```shell
dlm_tool status
```
```console
cluster nodeid 1 quorate 1 ring seq 32 32
daemon now 2177 fence_pid 0
node 1 M add 558 rem 0 fail 0 fence 0 at 0 0
node 2 M add 559 rem 0 fail 0 fence 0 at 0 0
```
Checking DRBD:
```shell
drbdadm status
```
```console
share role:Primary
  disk:UpToDate
  cplus-oiofs-2.novalocal role:Primary
    peer-disk:UpToDate
```
Checking CTDB:
```shell
ctdb status
ctdb -Y scriptstatus
```
```console
[root@cplus-oiofs-1 ~]# ctdb status
Number of nodes:2
pnn:0 172.31.130.23    OK (THIS NODE)
pnn:1 172.31.130.24    OK
Generation:262173107
Size:2
hash:0 lmaster:0
hash:1 lmaster:1
Recovery mode:NORMAL (0)
Recovery master:1
[root@cplus-oiofs-1 ~]# ctdb -Y scriptstatus
00.ctdb              OK         0.020 Fri Feb  1 08:55:53 2019
01.reclock           OK         0.018 Fri Feb  1 08:55:53 2019
05.system            OK         0.019 Fri Feb  1 08:55:53 2019
06.nfs               OK         0.005 Fri Feb  1 08:55:53 2019
10.external          DISABLED
10.interface         OK         0.010 Fri Feb  1 08:55:53 2019
11.natgw             OK         0.004 Fri Feb  1 08:55:53 2019
11.routing           DISABLED
13.per_ip_routing    OK         0.005 Fri Feb  1 08:55:53 2019
20.multipathd        OK         0.004 Fri Feb  1 08:55:53 2019
31.clamd             OK         0.005 Fri Feb  1 08:55:53 2019
40.vsftpd            OK         0.005 Fri Feb  1 08:55:53 2019
41.httpd             OK         0.004 Fri Feb  1 08:55:53 2019
49.winbind           OK         0.006 Fri Feb  1 08:55:53 2019
50.samba             DISABLED
60.nfs               OK         0.007 Fri Feb  1 08:55:53 2019
70.iscsi             OK         0.005 Fri Feb  1 08:55:53 2019
91.lvs               OK         0.005 Fri Feb  1 08:55:53 2019
99.timeout           OK         0.004 Fri Feb  1 08:55:53 2019
```
Checking Samba:
```shell
smbstatus
```
```console
[root@cplus-oiofs-1 ~]# smbstatus

Samba version 4.8.3
PID     Username     Group        Machine                                   Protocol Version  Encryption           Signing
----------------------------------------------------------------------------------------------------------------------------------------

Service      pid     Machine       Connected at                     Encryption   Signing
---------------------------------------------------------------------------------------------

No locked files
```

Checking exports SAMBA:
```shell
smbclient -L <VIP_OIOFS> -U <USER_SAMBA>
```
```console
[root@cplus-oiofs-2 ~]# smbclient -L 172.31.130.18 -U smbguest
Enter WORKGROUP\smbguest's password:

    Sharename       Type      Comment
    ---------       ----      -------
    MY_CONTAINER    Disk      Samba clusterized
    MY_CONTAINER2   Disk      Samba clusterized
    IPC$            IPC       IPC Service (Samba 4.8.3)
Reconnecting with SMB1 for workgroup listing.

    Server               Comment
    ---------            -------

    Workgroup            Master
    ---------            -------
```

Mount cifs on windows
```shell
net use t: \\<VIP_OIOFS>\MY_CONTAINER /user:<USER_SAMBA> <USER_SAMBA_PASSWORD>
net use v: \\<VIP_OIOFS>\MY_CONTAINER /user:<WORKGROUP>\<USER_AD> <USER_PASSWORD>
```
In case of a mount issue, check permissions: use `chown -R "<WORKGROUP>\\<USER_AD>" /mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER/`

How to fix that windows sees a negative size ?
Set a quota to the desired size on the container `_0` (here: 100 Terabytes)
```shell
openio container set MY_CONTAINER_0 --quota 109951162777600 --oio-ns OPENIO --oio-account MY_ACCOUNT
```

Mount cifs on linux:
```shell
mount -t cifs //<VIP_OIOFS>/MY_CONTAINER /mnt/foo -o username=smbguest,password=samba
```

Show NFS exports
```console
# showmount -e <VIP_OIOFS>
Export list for <VIP_OIOFS>:
/mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER *
```

Mount NFS on linux:
```console
# mount -t nfs <VIP_OIOFS>:/mnt/oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER /mnt/bar
```


Checking gridinit:
```shell
gridinit_cmd status
```

```console
root@node1 ~]# gridinit_cmd status
KEY                                           STATUS      PID GROUP
OPENIO-ecd-0                                  UP        28978 OPENIO,ecd,0
OPENIO-oiofs-OPENIO-MY_ACCOUNT-MY_CONTAINER   UP        29839 OPENIO,oiofs,OPENIO-MY_ACCOUNT-MY_CONTAINER
OPENIO-oioproxy-0                             UP        27635 OPENIO,oioproxy,0
```

Checking the VIP is mounted:
```shell
ip --color --brief a
```
```console
[root@cplus-oiofs-1 ~]# ip --color --brief a
lo               UNKNOWN        127.0.0.1/8 ::1/128
eth0             UP             172.31.120.29/24 fe80::f816:3eff:fe3d:2fc8/64
eth1             UP             172.31.130.23/24 172.31.130.18/24 fe80::f816:3eff:fe45:68ec/64
eth2             UP             172.31.140.21/24 fe80::f816:3eff:fe99:3207/64

```
Checking the cluster status:
```shell
pcs status
```
```console
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-23_172-31-130-24

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Feb  1 08:57:54 2019
Last change: Fri Feb  1 08:51:26 2019 by root via cibadmin on cplus-oiofs-1.novalocal

2 nodes configured
27 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-2.novalocal	(stonith:fence_openstack):	Started cplus-oiofs-1.novalocal
 fence_cplus-oiofs-1.novalocal	(stonith:fence_openstack):	Started cplus-oiofs-2.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: gfs2_share-clone [gfs2_share]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: gridinit-clone [gridinit]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: nfs-clone [nfs]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: ctdb-clone [ctdb]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: samba-clone [samba]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: gridinit-OPENIO-ecd-0-clone [gridinit-OPENIO-ecd-0]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: gridinit-OPENIO-oioproxy-0-clone [gridinit-OPENIO-oioproxy-0]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Master/Slave Set: gridinit-oiofs-OPENIO_MY_ACCOUNT_MY_CONTAINER-master [gridinit-oiofs-OPENIO_MY_ACCOUNT_MY_CONTAINER]
     Masters: [ cplus-oiofs-1.novalocal ]
     Slaves: [ cplus-oiofs-2.novalocal ]
 Master/Slave Set: gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2-master [gridinit-oiofs-OPENIO_MY_ACCOUNT2_MY_CONTAINER2]
     Masters: [ cplus-oiofs-1.novalocal ]
     Slaves: [ cplus-oiofs-2.novalocal ]
 Master/Slave Set: gridinit-oiofs-OPENIO_MY_ACCOUNT3_MY_CONTAINER3-master [gridinit-oiofs-OPENIO_MY_ACCOUNT3_MY_CONTAINER3]
     Masters: [ cplus-oiofs-1.novalocal ]
     Slaves: [ cplus-oiofs-2.novalocal ]
 vip-172-31-130-18	(ocf::heartbeat:IPaddr2):	Started cplus-oiofs-1.novalocal

Daemon Status:
  corosync: active/enabled
  pacemaker: active/ena
```
Checking if DLM is ok:
```shell
dlm_tool status
```
```console
cluster nodeid 1 quorate 1 ring seq 32 32
daemon now 2383 fence_pid 0
node 1 M add 558 rem 0 fail 0 fence 0 at 0 0
node 2 M add 559 rem 0 fail 0 fence 0 at 0 0
```
(https://fr.slideshare.net/EricRen2/dlm-knowledgesharing)

### How to check if oiofs is master or slave ?
```shell
curl -s 127.0.0.1:6999/conf|jq -r '.active_mode'
```
```console
[root@cplus-oiofs-1 ~]# curl -s 127.0.0.1:6999/conf|jq -r '.active_mode'
true
```

### How to set oiofs in master mode ?
```shell
curl -v -d '{"active_mode": true}'  127.0.0.1:6999/conf
```

### How to disable the cluster ? Stop monitoring to be able to modify the monitored resources ?
```shell
pcs property set maintenance-mode=true
```

### How to re-enable the cluster ?
```shell
pcs property set maintenance-mode=false
```

## Trouble shooting
### DRDB don't start

__errors__
```shell
TASK [DRBD - Reload if running] *********************************************************************
Friday 18 January 2019  11:22:10 +0000 (0:00:00.677)       0:03:04.709 ********
fatal: [node1]: FAILED! => changed=false
  msg: |-
    Unable to start service drbd: Job for drbd.service failed because the control process exited with error code. See "systemctl status drbd.service" and "journalctl -xe" for details.
fatal: [node2]: FAILED! => changed=false
  msg: |-
    Unable to start service drbd: Job for drbd.service failed because the control process exited with error code. See "systemctl status drbd.service" and "journalctl -xe" for details.
```
__Checks__
```shell
[root@cplus-oiofs-1 ~]# rpm -qa |grep drbd
drbd90-utils-9.6.0-1.el7.elrepo.x86_64
kmod-drbd90-9.0.16-1.el7_6.elrepo.x86_64
[root@cplus-oiofs-1 ~]# rpm -ql kmod-drbd90-9.0.16-1.el7_6.elrepo.x86_64
/etc/depmod.d/kmod-drbd90.conf
/lib/modules/3.10.0-957.el7.x86_64
/lib/modules/3.10.0-957.el7.x86_64/extra
/lib/modules/3.10.0-957.el7.x86_64/extra/drbd90
/lib/modules/3.10.0-957.el7.x86_64/extra/drbd90/drbd.ko
/lib/modules/3.10.0-957.el7.x86_64/extra/drbd90/drbd_transport_tcp.ko
/usr/share/doc/kmod-drbd90-9.0.16
/usr/share/doc/kmod-drbd90-9.0.16/COPYING
/usr/share/doc/kmod-drbd90-9.0.16/ChangeLog
/usr/share/doc/kmod-drbd90-9.0.16/README.md
[root@cplus-oiofs-1 ~]# modprobe drbd
modprobe: FATAL: Module drbd not found.
[root@cplus-oiofs-1 ~]# uname -r
3.10.0-862.14.4.el7.x86_64
```
__Solution__
```shell
[root@cplus-oiofs-1 ~]# reboot
[root@cplus-oiofs-1 ~]# uname -r
3.10.0-957.1.3.el7.x86_64
[root@cplus-oiofs-1 ~]# systemctl start drbd
[root@cplus-oiofs-2 ~]# systemctl start drbd
[root@cplus-oiofs-1 ~]# ll /dev/drbd0
brw-rw---- 1 root disk 147, 0 18 janv. 13:09 /dev/drbd0
[root@cplus-oiofs-1 ~]# drbdadm status
share role:Secondary
  disk:Diskless
  cplus-oiofs-2.novalocal role:Secondary
    peer-disk:Diskless
```

### DRDB `create-md` fails

__errors__

```shell
TASK [DRBD - Initialize the meta data storage] ******************************************************
Friday 18 January 2019  13:34:05 +0000 (0:00:10.314)       0:01:59.485 ********
fatal: [node1]: FAILED! => changed=true
  cmd:
  - drbdadm
  - create-md
  - share
  - --force
  delta: '0:00:00.021221'
  end: '2019-01-18 13:34:06.193128'
  failed_when_result: true
  msg: non-zero return code
  rc: 40
  start: '2019-01-18 13:34:06.171907'
  stderr: Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stderr_lines:
  - Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stdout: |-
    md_offset 16106123264
    al_offset 16106090496
    bm_offset 16105598976

    Found xfs filesystem
        15728640 kB data area apparently used
        15728124 kB left usable by current configuration

    Device size would be truncated, which
    would corrupt data and result in
    'access beyond end of device' errors.
    You need to either
       * use external meta data (recommended)
       * shrink that filesystem first
       * zero out the device (destroy the filesystem)
    Operation refused.
  stdout_lines: <omitted>
fatal: [node2]: FAILED! => changed=true
  cmd:
  - drbdadm
  - create-md
  - share
  - --force
  delta: '0:00:00.020982'
  end: '2019-01-18 13:34:06.225639'
  failed_when_result: true
  msg: non-zero return code
  rc: 40
  start: '2019-01-18 13:34:06.204657'
  stderr: Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stderr_lines:
  - Command 'drbdmeta 0 v09 /dev/vdb internal create-md 1 --force' terminated with exit code 40
  stdout: |-
    md_offset 16106123264
    al_offset 16106090496
    bm_offset 16105598976

    Found xfs filesystem
        15728640 kB data area apparently used
        15728124 kB left usable by current configuration

    Device size would be truncated, which
    would corrupt data and result in
    'access beyond end of device' errors.
    You need to either
       * use external meta data (recommended)
       * shrink that filesystem first
       * zero out the device (destroy the filesystem)
    Operation refused.
  stdout_lines: <omitted>
```

__Checks__
```shell
[root@cplus-oiofs-2 ~]# blkid
/dev/vda1: UUID="de86ba8a-914b-4104-9fd8-f9de800452ea" TYPE="xfs"
/dev/vdb: UUID="b7ce58df-ad50-4f51-9d72-82309baf261c" TYPE="xfs"
/dev/vdc: UUID="0c9c4213-4163-4559-befc-42f75c9677f6" TYPE="xfs"
```

__Solution__
```shell
[root@cplus-oiofs-1 ~]#  dd if=/dev/zero of=/dev/vdb
[root@cplus-oiofs-2 ~]#  dd if=/dev/zero of=/dev/vdb
[root@cplus-oiofs-2 ~]# blkid
/dev/vda1: UUID="de86ba8a-914b-4104-9fd8-f9de800452ea" TYPE="xfs"
/dev/vdc: UUID="0c9c4213-4163-4559-befc-42f75c9677f6" TYPE="xfs"
```

### GFS2 not found
__errors__
```shell
TASK [Fail if GFS2 path is not a valid block device] ************************************************
Friday 18 January 2019  16:14:04 +0000 (0:00:00.252)       0:02:23.645 ********
fatal: [node1]: FAILED! => changed=false
  msg: Source block device "/dev/drbd0" for GFS2 not found.
fatal: [node2]: FAILED! => changed=false
  msg: Source block device "/dev/drbd0" for GFS2 not found.
```

__Checks__
```shell
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:29:33 2019
Last change: Fri Jan 18 16:14:04 2019 by root via cibadmin on cplus-oiofs-1.novalocal

2 nodes configured
6 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Stopped: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Stopped: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Failed Actions:
* drbd_share_start_0 on cplus-oiofs-1.novalocal 'not configured' (6): call=17, status=complete, exitreason='',
    last-rc-change='Fri Jan 18 16:14:02 2019', queued=0ms, exec=31ms
```

__Solution__
```shell
[root@cplus-oiofs-1 ~]# pcs resource cleanup
Cleaned up all resources on all nodes
Waiting for 1 replies from the CRMd. OK
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:29:49 2019
Last change: Fri Jan 18 16:29:47 2019 by hacluster via crmd on cplus-oiofs-1.novalocal

2 nodes configured
6 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     dlm    (ocf::pacemaker:controld):    Starting cplus-oiofs-1.novalocal
     Stopped: [ cplus-oiofs-2.novalocal ]

Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled
[root@cplus-oiofs-1 ~]# pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:29:59 2019
Last change: Fri Jan 18 16:29:47 2019 by hacluster via crmd on cplus-oiofs-1.novalocal

2 nodes configured
6 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled

[root@cplus-oiofs-1 ~]# drbdadm status
share role:Primary
  disk:UpToDate
  cplus-oiofs-2.novalocal connection:StandAlone

```

### /dev/drbd0 doesn't mount
__errors__
```shell
TASK [GFS - Wait for Pacemaker to start the resource] ***********************************************
Friday 18 January 2019  16:33:37 +0000 (0:00:00.379)       0:02:03.016 ********
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (20 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (20 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (19 retries left).
changed: [node1]
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (18 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (17 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (16 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (15 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (14 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (13 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (12 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (11 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (10 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (9 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (8 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (7 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (6 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (5 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (4 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (3 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (2 retries left).
FAILED - RETRYING: GFS - Wait for Pacemaker to start the resource (1 retries left).
fatal: [node2]: FAILED! => changed=true
  attempts: 20
  cmd: mount|grep '^/dev/drbd0 on'|awk '{print $3}'
  delta: '0:00:00.003981'
  end: '2019-01-18 16:35:40.902724'
  failed_when_result: true
  rc: 0
  start: '2019-01-18 16:35:40.898743'
  stderr: ''
  stderr_lines: []
  stdout: ''
  stdout_lines: <omitted>
```

__Checks__
```shell
[root@cplus-oiofs-1 ~]#  pcs status
Cluster name: 172-31-130-3_172-31-130-4

WARNINGS:
Corosync and pacemaker node names do not match (IPs used in setup?)

Stack: corosync
Current DC: cplus-oiofs-1.novalocal (version 1.1.19-8.el7_6.2-c3c624ea3d) - partition with quorum
Last updated: Fri Jan 18 16:36:59 2019
Last change: Fri Jan 18 16:33:37 2019 by root via cibadmin on cplus-oiofs-1.novalocal

2 nodes configured
8 resources configured

Online: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]

Full list of resources:

 fence_cplus-oiofs-1.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-2.novalocal
 fence_cplus-oiofs-2.novalocal    (stonith:fence_openstack):    Started cplus-oiofs-1.novalocal
 Master/Slave Set: drbd_share-clone [drbd_share]
     Masters: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: dlm-clone [dlm]
     Started: [ cplus-oiofs-1.novalocal cplus-oiofs-2.novalocal ]
 Clone Set: gfs2_share-clone [gfs2_share]
     Started: [ cplus-oiofs-1.novalocal ]
     Stopped: [ cplus-oiofs-2.novalocal ]

Failed Actions:
* gfs2_share_start_0 on cplus-oiofs-2.novalocal 'unknown error' (1): call=35, status=complete, exitreason='Couldn't mount device [/dev/drbd0] as /mnt/share_gfs2',
    last-rc-change='Fri Jan 18 16:33:36 2019', queued=0ms, exec=73ms


Daemon Status:
  corosync: active/enabled
  pacemaker: active/enabled
  pcsd: active/enabled

[root@cplus-oiofs-1 ~]# tail -f /var/log/message &
   ... drbd share/0 drbd0: Split-Brain detected but unresolved, dropping connection!

[root@cplus-oiofs-1 ~]# drbdadm adjust share

```

__Solution__
Check the `My DRBD resource is in Unknown/Standalone state and I can't get my device in sync. What to do ?` paragraph

### My user Active Directory fails to access the samba export

__errors__

![Samba error permission](samba_error_permission.png)


__Checks__
```console
[root@cplus-oiofs2 ~]# ls -al /mnt/oiofs* -d
drwxr-xr-x 6 root        root               135 27 févr. 22:46 /mnt/oiofs_cache
drwxr-x--- 1 root        root              4096 28 févr. 12:23 /mnt/oiofs-OPENIO-act1-cont1
drwxr-x--- 1 smbguest    smbguest          4096 22 févr. 20:22 /mnt/oiofs-OPENIO-act2-cont2
drwxr-x--- 1 CPLUS\user1 CPLUS\my_ad_group 4096 27 févr. 22:46 /mnt/oiofs-OPENIO-act3-cont3
```
`/mnt/oiofs-OPENIO-act1-cont1` is owned by root

__Solution__

Change permisions on both servers
```shell
[root@cplus-oiofs2 ~]# id CPLUS\\user1
uid=3000(CPLUS\user1) gid=3007(CPLUS\domain users) groupes=3007(CPLUS\domain users),3008(CPLUS\my_ad_group),3009(CPLUS\group1),3003(BUILTIN\users)

[root@cplus-oiofs2 ~]# chown CPLUS\\user1 /mnt/oiofs-OPENIO-act1-cont1/
[root@cplus-oiofs2 ~]# chgrp CPLUS\\my_ad_group /mnt/oiofs-OPENIO-act1-cont1/

[root@cplus-oiofs2 ~]# ls -al /mnt/oiofs* -d
drwxr-xr-x 6 root        root               135 27 févr. 22:46 /mnt/oiofs_cache
drwxr-x--- 1 CPLUS\user1 CPLUS\my_ad_group 4096 28 févr. 12:23 /mnt/oiofs-OPENIO-act1-cont1
drwxr-x--- 1 smbguest    smbguest          4096 22 févr. 20:22 /mnt/oiofs-OPENIO-act2-cont2
drwxr-x--- 1 CPLUS\user1 CPLUS\my_ad_group 4096 27 févr. 22:46 /mnt/oiofs-OPENIO-act3-cont3

```

### my samba can not register to the Active Directory

__errors__
```console
TASK [samba : Add node to Active Directory] *************************************************************
Thursday 28 February 2019  10:03:38 +0000 (0:00:02.190)       0:00:23.909 *****
failed: [node1]
```


__Checks__
```shell
net ads join -U 'Administrator%Admin_AD_Password'
```

__Solution__

Check IP address, user Administrator, WORKGROUP and DOMAIN on the AD server.
```console
C:\Users\openio>Net Config Workstation
Computer name                        \\WIN2016
Full Computer name                   win2016.cplus.oio
User name                            openio

Workstation active on
        NetBT_Tcpip_{2E871AAA-CCF8-4A79-902F-675ADDE3FD43} (FA163E1A3663)
        NetBT_Tcpip_{B8A56940-05EC-428F-BA5F-8C447B7BF63D} (FA163EF5FFAE)

Software version                     Windows Server 2016 Standard Evaluation

Workstation domain                   CPLUS       <- WORKGROUP
Workstation Domain DNS Name          cplus.oio   <- domain
Logon domain                         CPLUS

COM Open Timeout (sec)               0
COM Send Count (byte)                16
COM Send Timeout (msec)              250
The command completed successfully.
```

```yaml
openio_samba_active_directory:
  nameserver_address: 172.31.130.25
  domain_name: "cplus.oio"
  workgroup: "CPLUS"
  admin: "Administrator"
  password: "fooBar1!"
  samba_address: "{{ hostvars[inventory_hostname]['ansible_' ~ openio_bind_interface]['ipv4']['address'] }}"
  id_range: "3000-7999"
```
